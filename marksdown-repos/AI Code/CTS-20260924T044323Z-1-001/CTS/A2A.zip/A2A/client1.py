import asyncio
import json

import httpx

from a2a.client import A2ACardResolver
from a2a.helpers import display_agent_card

from common.a2a_helpers import ask

URL = "http://localhost:9101"


async def main():
    # --- 1. Discovery: every A2A agent publishes a card at a well-known path
    async with httpx.AsyncClient() as http:
        card = await A2ACardResolver(http, URL).get_agent_card()
        print("=== Agent card ===")
        display_agent_card(card)

        # --- Raw JSON-RPC call (what the SDK does under the hood)
        payload = {
            "jsonrpc": "2.0", "id": "1", "method": "SendMessage",
            "params": {"message": {"role": "ROLE_USER", "messageId": "m-1",
                                   "parts": [{"text": "raw hello"}]}},
        }
        r = await http.post(URL + "/", json=payload, headers={"A2A-Version": "1.0"})
        print("\n=== Raw JSON-RPC response ===")
        print(json.dumps(r.json(), indent=2)[:600])

    # --- 2. SDK client
    result = await ask(URL, "Hi from the SDK client")
    print("\n=== SDK client ===")
    print(result["text"])


if __name__ == "__main__":
    asyncio.run(main())
