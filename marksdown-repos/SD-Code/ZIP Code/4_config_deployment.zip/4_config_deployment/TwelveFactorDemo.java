import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 33. THE 12-FACTOR APP (the cloud-native checklist), shown through four of its most important factors
 *
 *  I    Codebase      one repo per service, many deploys (dev/test/prod) from it
 *  II   Dependencies  declare them explicitly (pom.xml), never rely on "it's installed on that machine"
 *  III  Config        store config in the ENVIRONMENT                       <- Part 1
 *  IV   Backing svcs  treat DB/queue/cache as attached resources, swappable by changing a URL
 *  V    Build/release/run  strict separation, immutable artifacts
 *  VI   Processes     stateless; state lives in backing services            <- Part 2
 *  VII  Port binding  the app exports HTTP by listening on a port it is given
 *  VIII Concurrency   scale OUT by running more processes
 *  IX   Disposability fast startup, graceful shutdown                       <- Part 4
 *  X    Dev/prod parity keep environments as similar as possible
 *  XI   Logs          write events to stdout as a stream; the platform collects them   <- Part 3
 *  XII  Admin tasks   run one-off tasks (migrations) as separate processes
 *
 * Run: java TwelveFactorDemo.java
 */
public class TwelveFactorDemo {

    // =============================================================== Part 1: III. Config in the environment
    static void part1Config() {
        System.out.println("PART 1 - CONFIG comes from the environment (same build everywhere)");
        String port = System.getenv().getOrDefault("PORT", "8080");
        String dbUrl = System.getenv().getOrDefault("DATABASE_URL", "jdbc:h2:mem:local");
        System.out.println("   PORT         = " + port + (System.getenv("PORT") == null ? "   (default; platform normally injects it)" : ""));
        System.out.println("   DATABASE_URL = " + dbUrl + (System.getenv("DATABASE_URL") == null ? "   (default for laptop)" : ""));
        System.out.println("   Anti-pattern: 'if (hostname.equals(\"prod-box-7\")) useProdDb();' or a config file baked into the image.\n");
    }

    // =============================================================== Part 2: VI. Stateless processes
    static class SessionStore {                                   // stands in for Redis (a backing service)
        final Map<String, String> sessions = new ConcurrentHashMap<>();
    }

    static class AppInstance {
        final String name;
        final Map<String, String> localMemorySessions = new ConcurrentHashMap<>();   // BAD: state inside the process
        final SessionStore shared;                                                    // GOOD: state outside

        AppInstance(String name, SessionStore shared) {
            this.name = name;
            this.shared = shared;
        }

        String loginBad(String user) {
            String token = UUID.randomUUID().toString().substring(0, 6);
            localMemorySessions.put(token, user);
            return token;
        }

        String whoAmIBad(String token) {
            return localMemorySessions.getOrDefault(token, "NOT LOGGED IN");
        }

        String loginGood(String user) {
            String token = UUID.randomUUID().toString().substring(0, 6);
            shared.sessions.put(token, user);
            return token;
        }

        String whoAmIGood(String token) {
            return shared.sessions.getOrDefault(token, "NOT LOGGED IN");
        }
    }

    static void part2Stateless() {
        System.out.println("PART 2 - STATELESS processes (a load balancer sends consecutive requests to different instances)");
        SessionStore redis = new SessionStore();
        AppInstance i1 = new AppInstance("instance-1", redis);
        AppInstance i2 = new AppInstance("instance-2", redis);

        String badToken = i1.loginBad("ankur");
        System.out.println("   session kept in process memory: login on instance-1, next request lands on instance-2 -> "
                + i2.whoAmIBad(badToken) + "   <- user is logged out at random");

        String goodToken = i1.loginGood("ankur");
        System.out.println("   session kept in shared store  : login on instance-1, next request lands on instance-2 -> "
                + i2.whoAmIGood(goodToken));

        AppInstance i3 = new AppInstance("instance-3 (replacement after instance-1 was killed)", redis);
        System.out.println("   instance-1 is killed and replaced by a new pod                                  -> "
                + i3.whoAmIGood(goodToken) + "   <- nothing lost, instances are disposable\n");
    }

    // =============================================================== Part 3: XI. Logs as event streams
    static void log(String level, String traceId, String message) {
        // One JSON object per line on stdout. The platform (Docker/Kubernetes + Loki/ELK/CloudWatch) collects and indexes it.
        System.out.println("   {\"ts\":\"" + Instant.now() + "\",\"level\":\"" + level + "\",\"service\":\"payments\",\"traceId\":\""
                + traceId + "\",\"msg\":\"" + message + "\"}");
    }

    static void part3Logs() {
        System.out.println("PART 3 - LOGS are an event stream on stdout (no log files, no log rotation inside the app)");
        String trace = UUID.randomUUID().toString().substring(0, 8);
        log("INFO", trace, "payment received amount=500");
        log("WARN", trace, "gateway slow, retrying attempt=2");
        log("INFO", trace, "payment completed");
        System.out.println("   Structured (JSON) lines with a traceId can be searched across ALL services and instances.\n");
    }

    // =============================================================== Part 4: IX. Disposability
    static void part4Disposability() {
        System.out.println("PART 4 - DISPOSABILITY (fast start, graceful stop). This JVM registers a shutdown hook;");
        System.out.println("         it runs when the platform sends SIGTERM (or when this demo ends).");
        List<String> inFlight = new ArrayList<>(List.of("payment-101", "payment-102"));
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("\n   [shutdown hook] SIGTERM received");
            System.out.println("   [shutdown hook] 1. stop accepting new requests (readiness = false)");
            System.out.println("   [shutdown hook] 2. finish in-flight work: " + inFlight);
            inFlight.clear();
            System.out.println("   [shutdown hook] 3. close connections, flush logs, exit cleanly");
            System.out.println("   (Spring Boot: server.shutdown=graceful + spring.lifecycle.timeout-per-shutdown-phase=20s)");
        }));
    }

    public static void main(String[] args) {
        part1Config();
        part2Stateless();
        part3Logs();
        part4Disposability();
        System.out.println("\nDemo main() finished, JVM is exiting now...");
    }
}
