import java.util.Random;

/**
 * 37. BLUE-GREEN and CANARY deployments - the routing idea in code
 *
 * BIG-BANG deploy: replace v1 with v2 for everyone. A bug hits 100% of users.
 *
 * BLUE-GREEN: run TWO full environments. Blue = live (v1). Deploy v2 to Green, test it with no users on it,
 *   then flip the router: 100% of traffic moves at once. Rollback = flip back, instantly.
 *   + instant switch and rollback   - needs double the capacity; all users move at once
 *
 * CANARY: send a SMALL slice of real traffic to v2 first (5%), watch error rate, then widen: 5 -> 25 -> 50 -> 100.
 *   If the metrics look bad, send 0% and only the small slice was ever affected.
 *   + limits blast radius, uses real traffic   - needs good metrics; two versions run side by side
 *
 * In Kubernetes: blue-green = switch the Service selector; canary = Argo Rollouts / Flagger / service mesh weights.
 *
 * Run: java BlueGreenCanaryDemo.java
 */
public class BlueGreenCanaryDemo {

    // =============================================================== Blue-green
    static class BlueGreenRouter {
        String live = "blue";

        String route() {
            return live.equals("blue") ? "v1 (blue)" : "v2 (green)";
        }

        void flip() {
            live = live.equals("blue") ? "green" : "blue";
        }
    }

    static void blueGreen() {
        System.out.println("A) BLUE-GREEN");
        BlueGreenRouter router = new BlueGreenRouter();
        System.out.println("   v2 is deployed to GREEN and smoke-tested internally. Users still on: " + router.route());
        router.flip();
        System.out.println("   router flipped. All users now on: " + router.route());
        router.flip();
        System.out.println("   problem found! flip back. All users on: " + router.route() + "   (rollback took one switch)\n");
    }

    // =============================================================== Canary
    static class CanaryResult {
        int canaryUsers, stableUsers, canaryRequests, canaryErrors;
    }

    static CanaryResult runStep(int canaryPercent, double canaryErrorRate, Random random) {
        CanaryResult r = new CanaryResult();
        for (int user = 0; user < 1000; user++) {
            int bucket = Math.floorMod(("user-" + user).hashCode(), 100);     // sticky: a user stays on one version
            boolean toCanary = bucket < canaryPercent;
            if (toCanary) {
                r.canaryUsers++;
            } else {
                r.stableUsers++;
            }
            for (int req = 0; req < 5; req++) {                              // each user makes 5 requests
                if (toCanary) {
                    r.canaryRequests++;
                    if (random.nextDouble() < canaryErrorRate) {
                        r.canaryErrors++;
                    }
                }
            }
        }
        return r;
    }

    static void canary(String title, double v2ErrorRate) {
        System.out.println(title);
        final double ROLLBACK_THRESHOLD = 0.05;                              // roll back above 5% errors
        Random random = new Random(7);                                       // fixed seed: repeatable output
        int[] steps = {5, 25, 50, 100};
        for (int percent : steps) {
            CanaryResult r = runStep(percent, v2ErrorRate, random);
            double rate = r.canaryRequests == 0 ? 0 : r.canaryErrors / (double) r.canaryRequests;
            System.out.printf("   step %3d%%: %4d users on v2, %4d requests, %3d errors (%.1f%% error rate)",
                    percent, r.canaryUsers, r.canaryRequests, r.canaryErrors, rate * 100);
            if (rate > ROLLBACK_THRESHOLD) {
                System.out.printf("  -> ABOVE %.0f%% threshold: AUTO-ROLLBACK to 0%%%n", ROLLBACK_THRESHOLD * 100);
                System.out.println("   Only " + r.canaryUsers + " of 1000 users (" + r.canaryUsers / 10.0 + "%) ever saw the bug. "
                        + "A big-bang deploy would have hit all 1000.\n");
                return;
            }
            System.out.println("  -> healthy, widen the rollout");
        }
        System.out.println("   v2 promoted to 100%. Canary finished safely.\n");
    }

    public static void main(String[] args) {
        blueGreen();
        canary("B) CANARY with a HEALTHY v2 (0.5% errors)", 0.005);
        canary("C) CANARY with a BUGGY v2 (30% errors)", 0.30);

        System.out.println("Both strategies need: backward-compatible DB changes (expand, migrate, contract), "
                + "\nbecause old and new versions run at the same time, and good monitoring to decide promote or rollback.");
    }
}
