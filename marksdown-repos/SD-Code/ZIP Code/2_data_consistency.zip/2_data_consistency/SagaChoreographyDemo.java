import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * 17. SAGA - CHOREOGRAPHY (services react to each other's events, nobody is "in charge")
 *
 * Problem: placing an order touches 3 services, each with its own database. No single database
 * transaction can span them. A SAGA is a chain of LOCAL transactions; if a step fails, earlier
 * steps are undone by COMPENSATING actions (here: refund the payment).
 *
 * Choreography = a dance without a conductor:
 *    OrderCreated -> [Payment] -> PaymentCompleted -> [Inventory] -> InventoryReserved -> [Order confirms]
 *                              \-> PaymentFailed -> [Order cancels]
 *                                                    \-> InventoryFailed -> [Payment refunds] -> PaymentRefunded -> [Order cancels]
 *
 * Pros: loose coupling, no central component. Cons: the flow is spread across services and
 * harder to see/debug as it grows (compare with SagaOrchestrationDemo).
 *
 * The in-memory EventBus stands in for Kafka/RabbitMQ (and delivers synchronously to keep output readable).
 *
 * Run: java SagaChoreographyDemo.java
 */
public class SagaChoreographyDemo {

    interface Event {
    }

    record OrderCreated(String orderId, String item, int amount) implements Event {
    }

    record PaymentCompleted(String orderId, String item, int amount) implements Event {
    }

    record PaymentFailed(String orderId, String reason) implements Event {
    }

    record InventoryReserved(String orderId) implements Event {
    }

    record InventoryFailed(String orderId, String reason, int amount) implements Event {
    }

    record PaymentRefunded(String orderId) implements Event {
    }

    static class EventBus {
        private final Map<Class<?>, List<Consumer<Object>>> handlers = new HashMap<>();

        <T extends Event> void subscribe(Class<T> type, Consumer<T> handler) {
            handlers.computeIfAbsent(type, k -> new ArrayList<>()).add(e -> handler.accept(type.cast(e)));
        }

        void publish(Event event) {
            System.out.println("      ~ event published: " + event);
            for (Consumer<Object> h : handlers.getOrDefault(event.getClass(), List.of())) {
                h.accept(event);
            }
        }
    }

    // ---------------------------------------------------------------- Order service
    static class OrderService {
        final Map<String, String> status = new LinkedHashMap<>();
        private final EventBus bus;

        OrderService(EventBus bus) {
            this.bus = bus;
            bus.subscribe(PaymentFailed.class, e -> {
                status.put(e.orderId(), "CANCELLED (payment failed)");
            });
            bus.subscribe(InventoryReserved.class, e -> {
                status.put(e.orderId(), "CONFIRMED");
            });
            bus.subscribe(PaymentRefunded.class, e -> {
                status.put(e.orderId(), "CANCELLED (out of stock, payment refunded)");
            });
        }

        void placeOrder(String orderId, String item, int amount) {
            status.put(orderId, "PENDING");
            bus.publish(new OrderCreated(orderId, item, amount));
        }
    }

    // ---------------------------------------------------------------- Payment service
    static class PaymentService {
        int wallet = 1000;

        PaymentService(EventBus bus) {
            bus.subscribe(OrderCreated.class, e -> {
                if (e.amount() > wallet) {
                    bus.publish(new PaymentFailed(e.orderId(), "insufficient funds"));
                } else {
                    wallet -= e.amount();
                    bus.publish(new PaymentCompleted(e.orderId(), e.item(), e.amount()));
                }
            });
            bus.subscribe(InventoryFailed.class, e -> {          // COMPENSATING ACTION
                wallet += e.amount();
                bus.publish(new PaymentRefunded(e.orderId()));
            });
        }
    }

    // ---------------------------------------------------------------- Inventory service
    static class InventoryService {
        final Map<String, Integer> stock = new HashMap<>(Map.of("book", 5, "gold-coin", 0));

        InventoryService(EventBus bus) {
            bus.subscribe(PaymentCompleted.class, e -> {
                int left = stock.getOrDefault(e.item(), 0);
                if (left <= 0) {
                    bus.publish(new InventoryFailed(e.orderId(), "out of stock", e.amount()));
                } else {
                    stock.put(e.item(), left - 1);
                    bus.publish(new InventoryReserved(e.orderId()));
                }
            });
        }
    }

    public static void main(String[] args) {
        EventBus bus = new EventBus();
        OrderService orders = new OrderService(bus);
        PaymentService payments = new PaymentService(bus);
        InventoryService inventory = new InventoryService(bus);

        System.out.println("Scenario 1: everything works (book, 300)");
        orders.placeOrder("order-1", "book", 300);

        System.out.println("\nScenario 2: payment fails (book, 5000, wallet only has 700)");
        orders.placeOrder("order-2", "book", 5000);

        System.out.println("\nScenario 3: payment succeeds but item is out of stock (gold-coin, 200) -> refund");
        orders.placeOrder("order-3", "gold-coin", 200);

        System.out.println("\nFinal state:");
        orders.status.forEach((id, s) -> System.out.println("  " + id + " -> " + s));
        System.out.println("  wallet = " + payments.wallet + " (1000 - 300 for order-1; order-3 was refunded)");
        System.out.println("  book stock = " + inventory.stock.get("book"));
    }
}
