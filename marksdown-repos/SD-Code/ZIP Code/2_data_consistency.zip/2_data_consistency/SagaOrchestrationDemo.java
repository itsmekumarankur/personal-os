import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * 18. SAGA - ORCHESTRATION (one coordinator drives the steps)
 *
 * Choreography = dancers react to each other. Orchestration = a CONDUCTOR tells each musician when to play.
 *
 * The orchestrator knows the whole recipe:
 *     step 1 reserve stock  -> step 2 charge payment -> step 3 create shipment
 * and for each step the UNDO action. If step N fails, it runs the undo actions of steps N-1 ... 1
 * in REVERSE order.
 *
 * Pros: the whole flow is in ONE place (easy to read, monitor, change). Cons: the orchestrator is
 * an extra component that knows about many services (keep it free of business rules).
 * Real tools: Temporal, Camunda, Netflix Conductor, Spring State Machine, AWS Step Functions.
 *
 * Run: java SagaOrchestrationDemo.java
 */
public class SagaOrchestrationDemo {

    // ---------------- fake services with state we can inspect ----------------
    static int stock = 5;
    static int wallet = 1000;
    static boolean courierDown = false;

    record Step(String name, Runnable action, Runnable compensation) {
    }

    static class Orchestrator {
        boolean run(String sagaName, List<Step> steps) {
            System.out.println("  saga '" + sagaName + "' started");
            Deque<Step> completed = new ArrayDeque<>();
            for (Step step : steps) {
                try {
                    System.out.println("  -> " + step.name());
                    step.action().run();
                    completed.push(step);                       // remember what to undo later
                } catch (RuntimeException e) {
                    System.out.println("  !! step '" + step.name() + "' FAILED: " + e.getMessage());
                    compensate(completed);
                    return false;
                }
            }
            System.out.println("  saga completed successfully");
            return true;
        }

        private void compensate(Deque<Step> completed) {
            while (!completed.isEmpty()) {                       // LIFO = reverse order
                Step step = completed.pop();
                System.out.println("  <- undo '" + step.name() + "'");
                // Real systems: retry compensation until it succeeds, and make it idempotent.
                step.compensation().run();
            }
            System.out.println("  saga rolled back via compensations");
        }
    }

    static List<Step> orderSteps(int price) {
        List<Step> steps = new ArrayList<>();
        steps.add(new Step("reserve stock",
                () -> stock--,
                () -> stock++));
        steps.add(new Step("charge payment",
                () -> {
                    if (price > wallet) {
                        throw new IllegalStateException("insufficient funds");
                    }
                    wallet -= price;
                },
                () -> wallet += price));
        steps.add(new Step("create shipment",
                () -> {
                    if (courierDown) {
                        throw new IllegalStateException("courier service unavailable");
                    }
                },
                () -> {
                }));
        return steps;
    }

    static void printState() {
        System.out.println("  state -> stock=" + stock + ", wallet=" + wallet);
    }

    public static void main(String[] args) {
        Orchestrator orchestrator = new Orchestrator();

        System.out.println("Run 1: everything works");
        printState();
        orchestrator.run("order-1", orderSteps(300));
        printState();

        System.out.println("\nRun 2: courier is down, the LAST step fails, earlier steps are undone in reverse");
        courierDown = true;
        orchestrator.run("order-2", orderSteps(300));
        printState();
        System.out.println("  (stock and wallet are exactly as before run 2)");

        System.out.println("\nRun 3: payment fails (step 2), only step 1 needs undoing");
        courierDown = false;
        orchestrator.run("order-3", orderSteps(99_999));
        printState();

        System.out.println("\nProduction notes: persist the saga's progress so a crash mid-saga can resume or compensate,"
                + "\nretry compensations until they succeed, and make every step and undo idempotent.");
    }
}
