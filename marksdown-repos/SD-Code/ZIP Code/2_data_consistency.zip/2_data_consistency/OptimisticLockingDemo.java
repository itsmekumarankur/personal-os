/**
 * 24. OPTIMISTIC LOCKING (@Version in JPA)
 *
 * The "lost update" problem: two users read the same record, both change it, the last save
 * silently overwrites the first. Money disappears.
 *
 * Pessimistic locking: lock the row while someone edits (safe, but others wait; locks held across
 * network calls are dangerous).
 * Optimistic locking: assume conflicts are rare. Every row has a VERSION number.
 *   UPDATE account SET balance = ?, version = version + 1 WHERE id = ? AND version = ?   <-- expected version
 * If 0 rows were updated, someone else got there first -> reload and retry (or tell the user).
 * JPA does exactly this when you put @Version on a field (see spring_snippets/VersionedEntitySnippet.java).
 *
 * Run: java OptimisticLockingDemo.java
 */
public class OptimisticLockingDemo {

    record Row(int value, int version) {
    }

    // ---------------- naive store: last write wins ----------------
    static class NaiveStore {
        volatile int value = 0;
    }

    // ---------------- versioned store: UPDATE ... WHERE version = ? ----------------
    static class VersionedStore {
        private int value = 0;
        private int version = 1;

        synchronized Row read() {
            return new Row(value, version);
        }

        // returns true if "1 row was updated"
        synchronized boolean update(int expectedVersion, int newValue) {
            if (version != expectedVersion) {
                return false;                     // WHERE version = ? matched nothing
            }
            value = newValue;
            version++;
            return true;
        }
    }

    static void sleepTiny() {
        try {
            Thread.sleep(0, 200_000);             // widen the race window so the demo is reliable
        } catch (InterruptedException ignored) {
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("A) Two users edit the same account (balance 100)");
        VersionedStore account = new VersionedStore();
        account.update(1, 100);                                     // now value=100, version=2

        Row aliceRead = account.read();
        Row bobRead = account.read();
        System.out.println("   Alice reads " + aliceRead + ", Bob reads " + bobRead);

        boolean aliceOk = account.update(aliceRead.version(), aliceRead.value() + 50);   // deposit 50
        System.out.println("   Alice saves 150 -> " + (aliceOk ? "OK" : "CONFLICT"));

        boolean bobOk = account.update(bobRead.version(), bobRead.value() - 30);         // withdraw 30
        System.out.println("   Bob saves 70    -> " + (bobOk ? "OK" : "CONFLICT (someone changed it, version moved on)"));
        if (!bobOk) {
            Row fresh = account.read();
            account.update(fresh.version(), fresh.value() - 30);
            System.out.println("   Bob reloads " + fresh + ", reapplies his withdrawal -> " + account.read());
            System.out.println("   Correct final balance 120. Without versions Bob's save would have wiped Alice's deposit (70).");
        }

        System.out.println("\nB) Stress test: 4 threads each add 1, two thousand times (expected total 8000)");
        int threads = 4, perThread = 2000;

        NaiveStore naive = new NaiveStore();
        Thread[] ts = new Thread[threads];
        for (int i = 0; i < threads; i++) {
            ts[i] = new Thread(() -> {
                for (int j = 0; j < perThread; j++) {
                    int v = naive.value;               // read
                    sleepTiny();
                    naive.value = v + 1;               // write (blindly)
                }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        System.out.println("   no version check : " + naive.value + "  <- lost updates!");

        VersionedStore versioned = new VersionedStore();
        int[] retries = {0};
        for (int i = 0; i < threads; i++) {
            ts[i] = new Thread(() -> {
                for (int j = 0; j < perThread; j++) {
                    while (true) {
                        Row r = versioned.read();
                        sleepTiny();
                        if (versioned.update(r.version(), r.value() + 1)) {
                            break;
                        }
                        synchronized (retries) {
                            retries[0]++;              // conflict detected: loop, reload, retry
                        }
                    }
                }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        System.out.println("   optimistic locking: " + versioned.read().value() + "  <- exact, after " + retries[0] + " conflict retries");

        System.out.println("\nUse optimistic locking when conflicts are rare (most web apps). Use pessimistic locks (SELECT ... FOR UPDATE) "
                + "only for hot rows where retries would be constant.");
    }
}
