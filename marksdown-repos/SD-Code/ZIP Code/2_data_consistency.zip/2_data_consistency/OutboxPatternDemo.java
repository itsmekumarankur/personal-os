import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 20. OUTBOX PATTERN - save data and publish an event RELIABLY
 *
 * The "dual write" problem: a service must (1) save the order in its database and (2) publish
 * "OrderPlaced" to the message broker. Those are TWO systems, so no single transaction covers both.
 * If the service crashes between the two, the order exists but nobody is ever told.
 *
 * The fix: write the event into an OUTBOX TABLE in the SAME database transaction as the order
 * (atomic: both or neither). A separate RELAY process reads unsent outbox rows and publishes them,
 * marking them sent. If anything fails, the row stays unsent and is retried.
 *
 * Result: events are delivered AT LEAST ONCE (maybe twice), so consumers de-duplicate by event id.
 * (Production relays: a polling job, or Debezium change-data-capture.)
 *
 * Run: java OutboxPatternDemo.java
 */
public class OutboxPatternDemo {

    static class OutboxRow {
        final String eventId;
        final String payload;
        boolean sent;

        OutboxRow(String eventId, String payload, boolean sent) {
            this.eventId = eventId;
            this.payload = payload;
            this.sent = sent;
        }
    }

    /** A pretend database with an all-or-nothing transaction. */
    static class Database {
        List<String> orders = new ArrayList<>();
        List<OutboxRow> outbox = new ArrayList<>();

        void transaction(Runnable work) {
            List<String> ordersBackup = new ArrayList<>(orders);
            List<OutboxRow> outboxBackup = new ArrayList<>();
            for (OutboxRow r : outbox) {
                outboxBackup.add(new OutboxRow(r.eventId, r.payload, r.sent));
            }
            try {
                work.run();
            } catch (RuntimeException e) {                    // ROLLBACK: restore both tables
                orders = ordersBackup;
                outbox = outboxBackup;
                throw e;
            }
        }
    }

    static class Broker {
        final List<String> messages = new ArrayList<>();
        boolean down = false;

        void publish(OutboxRow row) {
            if (down) {
                throw new IllegalStateException("broker unavailable");
            }
            messages.add(row.eventId + ":" + row.payload);
        }
    }

    // ------------------------------------------------------------ relay
    static boolean crashAfterPublish = false;

    static void relay(Database db, Broker broker) {
        for (OutboxRow row : db.outbox) {
            if (row.sent) {
                continue;
            }
            try {
                broker.publish(row);
                if (crashAfterPublish) {                                  // process dies BEFORE marking sent
                    crashAfterPublish = false;
                    throw new IllegalStateException("relay crashed after publishing");
                }
                row.sent = true;
            } catch (IllegalStateException e) {
                System.out.println("    relay problem: " + e.getMessage() + " (row stays unsent, will retry)");
                return;
            }
        }
    }

    // ------------------------------------------------------------ idempotent consumer
    static class InventoryConsumer {
        private final Set<String> seen = new HashSet<>();
        int reservations = 0;

        void handle(String message) {
            String eventId = message.substring(0, message.indexOf(':'));
            if (!seen.add(eventId)) {
                System.out.println("    consumer: duplicate " + eventId + " ignored");
                return;
            }
            reservations++;
            System.out.println("    consumer: processed " + message);
        }
    }

    public static void main(String[] args) {
        System.out.println("A) WITHOUT outbox (dual write): save, then publish, crash in between");
        Database db1 = new Database();
        Broker broker1 = new Broker();
        db1.orders.add("order-1");                                         // committed
        System.out.println("   order saved. *** service crashes before publishing ***");
        System.out.println("   orders in DB: " + db1.orders + ", events published: " + broker1.messages
                + "   <- INCONSISTENT, inventory never learns about order-1");

        System.out.println("\nB) WITH outbox");
        Database db = new Database();
        Broker broker = new Broker();
        InventoryConsumer consumer = new InventoryConsumer();

        System.out.println("  1) crash INSIDE the transaction: both writes roll back together");
        try {
            db.transaction(() -> {
                db.orders.add("order-2");
                db.outbox.add(new OutboxRow("evt-2", "OrderPlaced order-2", false));
                throw new IllegalStateException("crash before commit");
            });
        } catch (IllegalStateException e) {
            System.out.println("    orders=" + db.orders + ", outbox rows=" + db.outbox.size() + "   <- consistent (neither)");
        }

        System.out.println("  2) successful transaction: order + outbox row saved atomically");
        db.transaction(() -> {
            db.orders.add("order-3");
            db.outbox.add(new OutboxRow("evt-3", "OrderPlaced order-3", false));
        });
        System.out.println("    orders=" + db.orders + ", outbox rows=" + db.outbox.size() + " (unsent)");

        System.out.println("  3) broker is DOWN when the relay runs: nothing lost, event waits in the outbox");
        broker.down = true;
        relay(db, broker);
        System.out.println("    published so far: " + broker.messages);

        System.out.println("  4) broker back, but the relay crashes right after publishing (before marking sent)");
        broker.down = false;
        crashAfterPublish = true;
        relay(db, broker);
        System.out.println("  5) relay restarts and publishes the still-unsent row again (at-least-once => duplicate)");
        relay(db, broker);
        System.out.println("    broker now holds: " + broker.messages);

        System.out.println("  6) consumer receives both copies, but de-duplicates by event id");
        broker.messages.forEach(consumer::handle);
        System.out.println("    inventory reservations made: " + consumer.reservations + " (exactly one)");
    }
}
