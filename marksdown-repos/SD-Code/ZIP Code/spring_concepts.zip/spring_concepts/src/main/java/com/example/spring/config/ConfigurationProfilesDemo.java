package com.example.spring.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.MapPropertySource;

import java.util.Map;

/**
 * 3. Java configuration, @Bean, @Profile and @Value
 *
 *  - @Configuration + @Bean: define beans in code (needed for third-party classes you cannot annotate)
 *  - @Profile: choose a different bean per environment (sandbox gateway in dev, live in prod)
 *  - @Value("${key:default}"): inject externalised config, with a fallback default
 *
 * In Spring Boot the same ideas appear as application-dev.yml / application-prod.yml
 * and @ConfigurationProperties.
 */
public class ConfigurationProfilesDemo {

    interface PaymentGateway {
        String charge(int amount);
    }

    static class SandboxGateway implements PaymentGateway {
        public String charge(int amount) {
            return "SANDBOX: pretended to charge " + amount;
        }
    }

    static class LiveGateway implements PaymentGateway {
        public String charge(int amount) {
            return "LIVE: really charged " + amount;
        }
    }

    static class FeeCalculator {
        private final double rate;

        FeeCalculator(double rate) {
            this.rate = rate;
        }

        double fee(int amount) {
            return amount * rate;
        }
    }

    @Configuration
    static class AppConfig {

        @Bean
        @Profile("dev")
        PaymentGateway sandboxGateway() {
            return new SandboxGateway();
        }

        @Bean
        @Profile("prod")
        PaymentGateway liveGateway() {
            return new LiveGateway();
        }

        // ${app.fee.rate:0.02} -> property if present, otherwise 0.02
        @Bean
        FeeCalculator feeCalculator(@Value("${app.fee.rate:0.02}") double rate) {
            return new FeeCalculator(rate);
        }
    }

    private static void runWith(String profile, Map<String, Object> properties) {
        try (var ctx = new AnnotationConfigApplicationContext()) {
            ctx.getEnvironment().setActiveProfiles(profile);
            ctx.getEnvironment().getPropertySources()
                    .addFirst(new MapPropertySource("demo-properties", properties));
            ctx.register(AppConfig.class);
            ctx.refresh();

            System.out.println("Profile '" + profile + "':");
            System.out.println("  " + ctx.getBean(PaymentGateway.class).charge(1000));
            System.out.println("  fee on 1000 = " + ctx.getBean(FeeCalculator.class).fee(1000));
        }
    }

    public static void main(String[] args) {
        runWith("dev", Map.of());                          // no property -> default 0.02
        runWith("prod", Map.of("app.fee.rate", "0.005"));  // property overrides the default
    }
}
