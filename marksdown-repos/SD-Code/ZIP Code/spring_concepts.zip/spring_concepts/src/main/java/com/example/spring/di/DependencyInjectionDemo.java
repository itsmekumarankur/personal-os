package com.example.spring.di;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

/**
 * 1. IoC + Dependency Injection
 *
 * IoC: you do not create collaborators with "new"; the Spring container creates
 * them and hands them to you.
 *
 * Key points shown here:
 *  - Constructor injection (preferred: final fields, easy to unit test, no reflection tricks)
 *  - Several beans of the same type -> @Primary picks the default
 *  - @Qualifier picks a specific bean by name
 */
public class DependencyInjectionDemo {

    interface NotificationService {
        void send(String message);
    }

    @Component("emailNotifier")
    static class EmailNotificationService implements NotificationService {
        public void send(String message) {
            System.out.println("  [EMAIL] " + message);
        }
    }

    @Component
    @Primary // used whenever someone asks for a NotificationService without a qualifier
    static class SmsNotificationService implements NotificationService {
        public void send(String message) {
            System.out.println("  [SMS]   " + message);
        }
    }

    @Component
    static class PaymentService {
        private final NotificationService defaultNotifier;
        private final NotificationService emailNotifier;

        // Single constructor => @Autowired is optional since Spring 4.3
        PaymentService(NotificationService defaultNotifier,
                       @Qualifier("emailNotifier") NotificationService emailNotifier) {
            this.defaultNotifier = defaultNotifier;
            this.emailNotifier = emailNotifier;
        }

        void pay(String user, int amount) {
            System.out.println("Paying " + amount + " for " + user);
            defaultNotifier.send("Payment of " + amount + " done");   // -> SMS (@Primary)
            emailNotifier.send("Receipt for payment of " + amount);   // -> Email (@Qualifier)
        }
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(
                EmailNotificationService.class,
                SmsNotificationService.class,
                PaymentService.class)) {

            ctx.getBean(PaymentService.class).pay("ankur", 500);
        }
    }
}
