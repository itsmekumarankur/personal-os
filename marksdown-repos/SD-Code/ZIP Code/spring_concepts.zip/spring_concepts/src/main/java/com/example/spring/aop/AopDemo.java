package com.example.spring.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 4. AOP (Aspect Oriented Programming)
 *
 * Cross-cutting concerns (audit, timing, security, retries) live in ONE aspect
 * instead of being copy-pasted into every service method.
 *
 * How it works: Spring wraps the bean in a PROXY. Callers talk to the proxy, the proxy
 * runs the advice, then calls your real method. This is the same mechanism behind
 * @Transactional, @Cacheable, @Async and @Retryable.
 *
 * Pitfall: calling a method on "this" bypasses the proxy, so no advice runs.
 */
public class AopDemo {

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    @interface Audited {
        String value();
    }

    @Component
    static class TransferService {

        @Audited("FUND_TRANSFER")
        public String transfer(String from, String to, int amount) {
            System.out.println("    business logic: moving " + amount + " from " + from + " to " + to);
            return "OK";
        }

        public void notAudited() {
            System.out.println("    business logic: no annotation, so no advice");
        }

        @Audited("SELF_CALL")
        public void audited() {
            System.out.println("    business logic: audited method");
        }

        public void callsAuditedViaThis() {
            this.audited(); // 'this' is the real object, NOT the proxy -> advice is skipped
        }
    }

    @Aspect
    @Component
    static class AuditAspect {

        @Around("@annotation(audited)")
        public Object audit(ProceedingJoinPoint pjp, Audited audited) throws Throwable {
            String method = pjp.getSignature().getName();
            System.out.println("  >> [" + audited.value() + "] before " + method);
            long start = System.nanoTime();
            try {
                return pjp.proceed(); // call the real method
            } finally {
                long micros = (System.nanoTime() - start) / 1_000;
                System.out.println("  << [" + audited.value() + "] after " + method + " (" + micros + " us)");
            }
        }
    }

    @Configuration
    @EnableAspectJAutoProxy
    static class AopConfig {
    }

    public static void main(String[] args) {
        try (var ctx = new AnnotationConfigApplicationContext(
                AopConfig.class, TransferService.class, AuditAspect.class)) {

            TransferService service = ctx.getBean(TransferService.class);
            System.out.println("Bean class is a proxy: " + service.getClass().getSimpleName());

            System.out.println("1) annotated method:");
            service.transfer("ACC-1", "ACC-2", 500);

            System.out.println("2) method without annotation:");
            service.notAudited();

            System.out.println("3) self-invocation through 'this' (advice silently skipped):");
            service.callsAuditedViaThis();
        }
    }
}
