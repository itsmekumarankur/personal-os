package com.example.snippets;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;

/**
 * Topic 1: calling another service over REST in Spring. NOT compiled in the sandbox it was written in.
 *
 * Dependencies: spring-boot-starter-web (RestClient, RestTemplate)
 *               spring-boot-starter-webflux (WebClient, reactive)
 *
 * Which one?
 *   RestClient   -> NEW default for blocking calls (Spring 6.1+ / Boot 3.2+). Fluent API.
 *   RestTemplate -> old blocking client, in maintenance mode. You will meet it in legacy code.
 *   WebClient    -> non-blocking / reactive. Use when your stack is reactive or you need parallel calls.
 */
public class RestClientSnippets {

    record Price(String symbol, double price) {
    }

    // ------------------------------------------------------------------ 1) RestClient (blocking, modern)
    @Component
    static class PricingClientWithRestClient {
        private final RestClient http;

        PricingClientWithRestClient(RestClient.Builder builder) {
            SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
            factory.setConnectTimeout(1000);        // ALWAYS set timeouts (see the resilience demos)
            factory.setReadTimeout(1000);

            this.http = builder
                    .baseUrl("http://pricing-service")      // with service discovery this is the logical name
                    .requestFactory(factory)
                    .build();
        }

        Price getPrice(String symbol) {
            return http.get()
                    .uri("/prices/{symbol}", symbol)
                    .retrieve()
                    .onStatus(HttpStatusCode::is4xxClientError, (request, response) -> {
                        throw new IllegalArgumentException("Unknown symbol " + symbol);
                    })
                    .body(Price.class);                     // JSON -> Price via Jackson
        }

        Price createQuote(Price request) {
            return http.post()
                    .uri("/quotes")
                    .body(request)                          // Price -> JSON
                    .retrieve()
                    .body(Price.class);
        }
    }

    // ------------------------------------------------------------------ 2) RestTemplate (legacy blocking)
    @Component
    static class PricingClientWithRestTemplate {
        private final RestTemplate restTemplate = new RestTemplate();

        Price getPrice(String symbol) {
            return restTemplate.getForObject("http://pricing-service/prices/{symbol}", Price.class, symbol);
        }
    }

    // ------------------------------------------------------------------ 3) WebClient (non-blocking)
    @Component
    static class PricingClientWithWebClient {
        private final WebClient web = WebClient.builder().baseUrl("http://pricing-service").build();

        Mono<Price> getPrice(String symbol) {
            return web.get()
                    .uri("/prices/{symbol}", symbol)
                    .retrieve()
                    .bodyToMono(Price.class)
                    .timeout(Duration.ofSeconds(1));        // reactive timeout
        }
        // Calling two services in parallel:
        //   Mono.zip(getPrice("INFY"), getPrice("TCS")).map(t -> ...)
    }
}
