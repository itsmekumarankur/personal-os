package com.example.snippets;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Topic 4: Feign declarative client. NOT compiled in the sandbox it was written in.
 *
 * Dependency:  org.springframework.cloud:spring-cloud-starter-openfeign
 *              (+ the Spring Cloud BOM matching your Spring Boot version)
 *
 * application.yml (timeouts are essential):
 *   spring:
 *     cloud:
 *       openfeign:
 *         client:
 *           config:
 *             pricing-service:
 *               connectTimeout: 1000
 *               readTimeout: 2000
 *
 * See DeclarativeClientDemo.java for a runnable explanation of how the proxy works.
 */
@SpringBootApplication
@EnableFeignClients                       // scan for @FeignClient interfaces and create proxies
public class FeignSnippet {

    record Price(String symbol, double price) {
    }

    record QuoteRequest(String symbol, int qty) {
    }

    // The interface IS the client. Spring Cloud creates the implementation at startup.
    // "pricing-service" is resolved through service discovery / load balancing,
    // or pin a URL with:  url = "${pricing.url}"
    @FeignClient(name = "pricing-service", fallback = PricingFallback.class)
    interface PricingClient {

        @GetMapping("/prices/{symbol}")
        Price getPrice(@PathVariable("symbol") String symbol);

        @PostMapping("/quotes")
        Price createQuote(@RequestBody QuoteRequest request);
    }

    // Used when the call fails (needs spring.cloud.openfeign.circuitbreaker.enabled=true)
    @org.springframework.stereotype.Component
    static class PricingFallback implements PricingClient {
        public Price getPrice(String symbol) {
            return new Price(symbol, 0.0);   // safe, clearly "unknown" value
        }

        public Price createQuote(QuoteRequest request) {
            throw new IllegalStateException("pricing-service unavailable, cannot create quote now");
        }
    }

    @Service
    static class OrderService {
        private final PricingClient pricing;           // inject it like any bean

        OrderService(PricingClient pricing) {
            this.pricing = pricing;
        }

        double total(String symbol, int qty) {
            return pricing.getPrice(symbol).price() * qty;
        }
    }

    public static void main(String[] args) {
        SpringApplication.run(FeignSnippet.class, args);
    }
}
