package com.example.snippets;

import com.example.pricing.grpc.PriceReply;
import com.example.pricing.grpc.PriceRequest;
import com.example.pricing.grpc.PriceServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.TimeUnit;

/**
 * Topic 5: a gRPC server and client in plain Java (no Spring needed).
 * NOT compiled in the sandbox it was written in.
 *
 * The classes PriceRequest, PriceReply and PriceServiceGrpc do not exist in the source tree;
 * they are GENERATED from price.proto by the protobuf Maven plugin.
 *
 * pom.xml essentials:
 *   dependencies: io.grpc:grpc-netty-shaded, io.grpc:grpc-protobuf, io.grpc:grpc-stub (same version)
 *   build:        org.xolstice.maven.plugins:protobuf-maven-plugin (compile + compile-custom goals)
 *                 together with kr.motd.maven:os-maven-plugin (extension)
 *
 * Spring Boot users: net.devh:grpc-spring-boot-starter wraps this with @GrpcService / @GrpcClient.
 */
public class GrpcSnippet {

    // ----------------------------------------------------------- SERVER
    static class PriceServiceImpl extends PriceServiceGrpc.PriceServiceImplBase {
        @Override
        public void getPrice(PriceRequest request, StreamObserver<PriceReply> responseObserver) {
            PriceReply reply = PriceReply.newBuilder()
                    .setSymbol(request.getSymbol())
                    .setPrice(1523.40)
                    .setEpochMillis(System.currentTimeMillis())
                    .build();
            responseObserver.onNext(reply);        // send the response
            responseObserver.onCompleted();        // finish the call
        }

        @Override
        public void streamPrices(PriceRequest request, StreamObserver<PriceReply> responseObserver) {
            for (int i = 0; i < 5; i++) {          // push 5 ticks, then end
                responseObserver.onNext(PriceReply.newBuilder()
                        .setSymbol(request.getSymbol())
                        .setPrice(1523.40 + i)
                        .setEpochMillis(System.currentTimeMillis())
                        .build());
            }
            responseObserver.onCompleted();
        }
    }

    // ----------------------------------------------------------- CLIENT
    static void callIt() throws Exception {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 9090)
                .usePlaintext()                    // use TLS in real life
                .build();

        // Blocking stub: looks like a local method call. Deadline = timeout (set one on EVERY call)
        PriceServiceGrpc.PriceServiceBlockingStub stub =
                PriceServiceGrpc.newBlockingStub(channel).withDeadlineAfter(1, TimeUnit.SECONDS);

        PriceReply reply = stub.getPrice(PriceRequest.newBuilder().setSymbol("INFY").build());
        System.out.println(reply.getSymbol() + " = " + reply.getPrice());

        channel.shutdown().awaitTermination(2, TimeUnit.SECONDS);
    }

    public static void main(String[] args) throws Exception {
        Server server = ServerBuilder.forPort(9090)
                .addService(new PriceServiceImpl())
                .build()
                .start();
        System.out.println("gRPC server listening on 9090");
        callIt();
        server.shutdown();
    }
}
