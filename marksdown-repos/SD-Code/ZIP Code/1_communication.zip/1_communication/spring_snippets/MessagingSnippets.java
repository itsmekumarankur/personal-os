package com.example.snippets;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Topic 3: Kafka and RabbitMQ with Spring. NOT compiled in the sandbox it was written in.
 * Concept demo (runnable): MessagingDemo.java
 *
 * Dependencies:
 *   Kafka:    org.springframework.kafka:spring-kafka
 *   RabbitMQ: org.springframework.boot:spring-boot-starter-amqp
 *
 * application.yml (Kafka):
 *   spring:
 *     kafka:
 *       bootstrap-servers: localhost:9092
 *       producer:
 *         key-serializer:   org.apache.kafka.common.serialization.StringSerializer
 *         value-serializer: org.apache.kafka.common.serialization.StringSerializer
 *         acks: all                              # wait for all replicas: safest
 *       consumer:
 *         group-id: billing                      # consumer GROUP (see MessagingDemo)
 *         auto-offset-reset: earliest            # where a brand-new group starts
 *         enable-auto-commit: false
 *         key-deserializer:   org.apache.kafka.common.serialization.StringDeserializer
 *         value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
 *
 * application.yml (RabbitMQ):
 *   spring:
 *     rabbitmq:
 *       host: localhost
 *       port: 5672
 */
public class MessagingSnippets {

    // =========================================================== KAFKA
    @Component
    static class PaymentEventProducer {
        private final KafkaTemplate<String, String> kafka;

        PaymentEventProducer(KafkaTemplate<String, String> kafka) {
            this.kafka = kafka;
        }

        void publish(String accountId, String json) {
            // key = accountId  => all events of one account go to the same partition => stay in order
            kafka.send("payments", accountId, json);
        }
    }

    @Component
    static class BillingConsumer {
        // Run several instances of this service with the same groupId = they share the partitions.
        @KafkaListener(topics = "payments", groupId = "billing")
        void onPayment(String json) {
            System.out.println("billing got " + json);
            // Make this handler IDEMPOTENT: the same message can be delivered twice (at-least-once)
        }
    }

    @Component
    static class AnalyticsConsumer {
        // Different group = receives EVERY message too (its own copy of the stream)
        @KafkaListener(topics = "payments", groupId = "analytics")
        void onPayment(String json) {
            System.out.println("analytics got " + json);
        }
    }

    // =========================================================== RABBITMQ
    // Model: producer -> exchange -> (routing key) -> queue -> consumer.
    // A message in a queue is delivered to ONE of the competing consumers (work queue), then removed.
    @Component
    static class EmailRequestProducer {
        private final RabbitTemplate rabbit;

        EmailRequestProducer(RabbitTemplate rabbit) {
            this.rabbit = rabbit;
        }

        void send(String json) {
            rabbit.convertAndSend("notifications.exchange", "email", json);
        }
    }

    @Component
    static class EmailWorker {
        @RabbitListener(queues = "email.queue")
        void handle(String json) {
            System.out.println("sending email for " + json);
        }
    }

    // Kafka vs RabbitMQ in one line:
    //   Kafka    = a durable LOG you can replay; many independent groups; huge throughput; ordering per partition.
    //   RabbitMQ = a smart ROUTER of messages to queues; message removed after it is consumed; flexible routing.
}
