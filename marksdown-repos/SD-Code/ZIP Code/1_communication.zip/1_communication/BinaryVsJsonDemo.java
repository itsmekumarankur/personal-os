import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 5. gRPC BASICS - the idea of a CONTRACT-FIRST, BINARY protocol
 *
 * gRPC = (1) a .proto contract file  +  (2) compact binary messages (Protocol Buffers)  +  (3) HTTP/2.
 *
 * REST/JSON: field NAMES travel in every message ("symbol", "price"...), readable but bulky,
 *            and the "contract" is just documentation.
 * gRPC:      both sides compile the same .proto, so the receiver already knows the fields.
 *            Only VALUES travel, tagged by field numbers (not names). Smaller, faster, type-safe.
 *
 * This demo does NOT use real protobuf. It mimics the core idea with a hand-made binary format so
 * you can see size differences and the importance of a shared contract.
 *
 * The real contract and Java server/client snippet: spring_snippets/price.proto and GrpcSnippet.java
 *
 * Run: java BinaryVsJsonDemo.java
 */
public class BinaryVsJsonDemo {

    record Quote(String symbol, double price, long volume, long epochMillis) {
    }

    static String toJson(Quote q) {
        return "{\"symbol\":\"" + q.symbol() + "\",\"price\":" + q.price()
                + ",\"volume\":" + q.volume() + ",\"epochMillis\":" + q.epochMillis() + "}";
    }

    // Binary format = the "contract": symbol(UTF), price(double), volume(long), time(long) IN THIS ORDER
    static byte[] toBinary(Quote q) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeUTF(q.symbol());
        out.writeDouble(q.price());
        out.writeLong(q.volume());
        out.writeLong(q.epochMillis());
        return bytes.toByteArray();
    }

    static Quote fromBinary(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        return new Quote(in.readUTF(), in.readDouble(), in.readLong(), in.readLong());
    }

    // Protobuf's trick for integers: "varint" = small numbers take fewer bytes
    static int varintSize(long value) {
        int size = 1;
        while ((value >>>= 7) != 0) {
            size++;
        }
        return size;
    }

    public static void main(String[] args) throws Exception {
        Quote quote = new Quote("INFY", 1523.40, 1_250_000L, 1_761_200_000_000L);

        String json = toJson(quote);
        byte[] binary = toBinary(quote);
        System.out.println("1) Same data, two encodings");
        System.out.println("   JSON   (" + json.getBytes(StandardCharsets.UTF_8).length + " bytes): " + json);
        System.out.println("   Binary (" + binary.length + " bytes): not human readable, no field names inside");

        System.out.println("\n2) Both sides share the contract, so decoding is exact");
        System.out.println("   decoded: " + fromBinary(binary));

        System.out.println("\n3) Without the contract (reader assumes a different field order) you get garbage");
        try {
            DataInputStream wrong = new DataInputStream(new ByteArrayInputStream(binary));
            String symbol = wrong.readUTF();
            long volume = wrong.readLong();          // really a double was written here
            System.out.println("   symbol=" + symbol + ", volume=" + volume + "  <- nonsense, nobody warned us");
        } catch (Exception e) {
            System.out.println("   failed: " + e);
        }
        System.out.println("   This is why gRPC generates BOTH client and server code from one .proto file.");

        System.out.println("\n4) Varint: protobuf spends fewer bytes on small numbers (fixed long = 8 bytes)");
        for (long v : new long[]{1, 300, 1_250_000L, 1_761_200_000_000L}) {
            System.out.printf("   value %,16d -> %d byte(s) as varint%n", v, varintSize(v));
        }

        System.out.println("\nWhen to pick gRPC: internal service-to-service calls with high volume, streaming, or strict contracts."
                + "\nWhen to keep REST: public APIs, browsers, easy debugging with curl.");
    }
}
