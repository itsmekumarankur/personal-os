import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.StringJoiner;

/**
 * 7. DTOs vs ENTITIES - why services never share their internal models
 *
 * ENTITY = how a service stores data internally (database columns, internal flags, versions).
 *          It changes whenever the owning team refactors storage.
 * DTO    = Data Transfer Object = the public CONTRACT of an API. It changes only on purpose.
 *
 * If you return entities directly you (1) leak internals (password hashes, fraud flags),
 * and (2) every internal refactor silently breaks every consumer.
 *
 * If two services share one entity class (a shared library), they can no longer evolve or deploy
 * independently: that is a distributed monolith.
 *
 * Run: java DtoVsEntityDemo.java
 */
public class DtoVsEntityDemo {

    // ---- Internal entity, version 1 ----
    static class AccountEntityV1 {
        Long id = 42L;
        String ownerName = "Ankur";
        String passwordHash = "$2a$10$abc...secret-hash";   // must NEVER leave the service
        long balancePaise = 100_000;                         // stored in paise
        int version = 7;                                     // optimistic-lock counter
        boolean fraudFlag = false;                           // internal risk decision
    }

    // ---- Same entity after an internal refactor (renamed + new internal field) ----
    static class AccountEntityV2 {
        Long id = 42L;
        String ownerName = "Ankur";
        String passwordHash = "$2a$10$abc...secret-hash";
        long balanceMinorUnits = 100_000;                    // RENAMED
        int version = 7;
        boolean fraudFlag = false;
        double internalRiskScore = 0.12;                     // NEW
    }

    // ---- The public contract ----
    record AccountDto(String id, String owner, String balance) {
        static AccountDto from(AccountEntityV1 e) {
            return new AccountDto(String.valueOf(e.id), e.ownerName, String.format("%.2f", e.balancePaise / 100.0));
        }

        static AccountDto from(AccountEntityV2 e) {          // mapper adapts; the CONTRACT stays the same
            return new AccountDto(String.valueOf(e.id), e.ownerName, String.format("%.2f", e.balanceMinorUnits / 100.0));
        }
    }

    // tiny reflection-based JSON, only to print objects
    static String toJson(Object o) throws Exception {
        StringJoiner json = new StringJoiner(",", "{", "}");
        for (Field f : o.getClass().getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.isSynthetic()) {
                continue;
            }
            f.setAccessible(true);
            Object v = f.get(o);
            String value = (v instanceof Number || v instanceof Boolean) ? String.valueOf(v) : "\"" + v + "\"";
            json.add("\"" + f.getName() + "\":" + value);
        }
        return json.toString();
    }

    public static void main(String[] args) throws Exception {
        System.out.println("1) BAD: API returns the entity directly");
        System.out.println("   " + toJson(new AccountEntityV1()));
        System.out.println("   -> leaks passwordHash, version, fraudFlag to every caller\n");

        System.out.println("2) The owning team refactors storage (rename + add a field). Entity JSON changes:");
        System.out.println("   " + toJson(new AccountEntityV2()));
        System.out.println("   -> consumers that read 'balancePaise' are now broken, with no warning\n");

        System.out.println("3) GOOD: API returns a DTO. Only the promised fields, same shape before and after the refactor:");
        System.out.println("   before refactor: " + toJson(AccountDto.from(new AccountEntityV1())));
        System.out.println("   after  refactor: " + toJson(AccountDto.from(new AccountEntityV2())));

        System.out.println("\nRules:");
        System.out.println("  - one service OWNS its entities; others only see DTOs/events (the contract)");
        System.out.println("  - map at the boundary (MapStruct or hand-written mappers)");
        System.out.println("  - use different DTOs for requests and responses (clients must not be able to set 'version' or 'fraudFlag')");
        System.out.println("  - don't share entity JARs between services; share contracts (OpenAPI / .proto / event schemas) instead");
    }
}
