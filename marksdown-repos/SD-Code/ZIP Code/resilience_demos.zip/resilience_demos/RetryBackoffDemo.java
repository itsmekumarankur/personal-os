import java.util.concurrent.Callable;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 9. RETRY WITH BACKOFF (hand-written version; Resilience4j version is in the spring folder).
 *
 * Picture: you call a friend and the line is busy.
 *  - Bad: redial 100 times per second (you hammer an already struggling service,
 *    and so does everybody else: a "retry storm").
 *  - Good: wait a bit, try again; wait longer, try again (exponential backoff);
 *    add randomness (jitter) so thousands of clients do not all retry at the same instant;
 *    give up after a few attempts.
 *
 * Rules of good retries:
 *  1. Only retry TEMPORARY errors (503, timeout). Never retry "400 bad request".
 *  2. Limit attempts.
 *  3. Back off, with jitter.
 *  4. Only retry operations that are safe to repeat (see IdempotencyDemo).
 *
 * Run: java RetryBackoffDemo.java
 */
public class RetryBackoffDemo {

    static class TransientException extends RuntimeException {   // worth retrying
        TransientException(String m) {
            super(m);
        }
    }

    static class PermanentException extends RuntimeException {    // retrying is pointless
        PermanentException(String m) {
            super(m);
        }
    }

    /** A service that fails the first N calls, then recovers. */
    static class FlakyService {
        private final int failFirst;
        private int calls = 0;

        FlakyService(int failFirst) {
            this.failFirst = failFirst;
        }

        String call() {
            calls++;
            if (calls <= failFirst) {
                throw new TransientException("503 Service Unavailable (call #" + calls + ")");
            }
            return "SUCCESS on call #" + calls;
        }
    }

    static <T> T retry(Callable<T> action, int maxAttempts, long baseDelayMs) throws Exception {
        for (int attempt = 1; ; attempt++) {
            try {
                return action.call();
            } catch (TransientException e) {                       // only temporary errors are retried
                if (attempt == maxAttempts) {
                    System.out.println("  attempt " + attempt + " failed: " + e.getMessage() + "  -> giving up");
                    throw e;
                }
                long ceiling = baseDelayMs * (1L << (attempt - 1));       // 100, 200, 400, 800 ...
                long delay = ThreadLocalRandom.current().nextLong(ceiling / 2, ceiling + 1); // jitter
                System.out.println("  attempt " + attempt + " failed: " + e.getMessage()
                        + "  -> wait " + delay + " ms (max " + ceiling + ")");
                Thread.sleep(delay);
            }
            // PermanentException is NOT caught: it escapes immediately, no retry
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("A) No retry: one blip and the user sees an error");
        try {
            new FlakyService(2).call();
        } catch (Exception e) {
            System.out.println("  failed: " + e.getMessage());
        }

        System.out.println("\nB) Retry with exponential backoff + jitter: service recovers on call #4");
        FlakyService recovering = new FlakyService(3);
        System.out.println("  result: " + retry(recovering::call, 5, 100));

        System.out.println("\nC) Service stays down: bounded attempts, then give up (no infinite loop)");
        try {
            retry(new FlakyService(99)::call, 4, 100);
        } catch (TransientException e) {
            System.out.println("  final failure surfaced to caller");
        }

        System.out.println("\nD) Permanent error (400): not retried at all");
        try {
            retry(() -> {
                throw new PermanentException("400 Invalid account number");
            }, 5, 100);
        } catch (PermanentException e) {
            System.out.println("  failed immediately: " + e.getMessage());
        }

        System.out.println("\nWhy backoff matters: if 1000 clients retry every 100 ms, a struggling service "
                + "gets 10,000 extra requests/second right when it can least handle them.");
    }
}
