import java.util.List;
import java.util.function.Supplier;

/**
 * 13. FALLBACKS AND GRACEFUL DEGRADATION
 *
 * Picture: the lift is broken. A good building puts up a "use the stairs" sign.
 * A bad building collapses. Same idea: when a dependency fails, give a reduced but
 * useful answer instead of an error page.
 *
 * Part A: a price lookup with 3 levels of fallback
 *         live price -> last cached price (marked stale) -> safe default message
 * Part B: a dashboard where the main data is critical, but "recommendations"
 *         are optional. If recommendations fail, the page still renders.
 *
 * Run: java FallbackDemo.java
 */
public class FallbackDemo {

    // ---------- Part A ----------
    static boolean liveFeedUp = true;
    static Double cachedPrice = null;
    static long cachedAt = 0;

    static double fetchLivePrice(String symbol) {
        if (!liveFeedUp) {
            throw new RuntimeException("market data feed unreachable");
        }
        return 1523.40;
    }

    static String getPrice(String symbol) {
        try {
            double live = fetchLivePrice(symbol);
            cachedPrice = live;                              // refresh cache on every success
            cachedAt = System.currentTimeMillis();
            return "LIVE   : " + symbol + " = " + live;
        } catch (Exception liveFailure) {
            if (cachedPrice != null) {                       // fallback level 1
                return "CACHED : " + symbol + " = " + cachedPrice + "  (stale, live feed down)";
            }
            return "DEFAULT: " + symbol + " price temporarily unavailable";  // fallback level 2
        }
    }

    // ---------- Part B ----------
    static String loadPortfolioValue() {                     // CRITICAL: no sensible fallback
        return "Portfolio value: 4,25,000";
    }

    static List<String> loadRecommendations() {              // OPTIONAL
        throw new RuntimeException("recommendation engine timed out");
    }

    static <T> T withFallback(Supplier<T> primary, T fallback, String what) {
        try {
            return primary.get();
        } catch (Exception e) {
            System.out.println("    (" + what + " failed: " + e.getMessage() + " -> using fallback)");
            return fallback;
        }
    }

    public static void main(String[] args) {
        System.out.println("A) Layered fallbacks for a price lookup");
        System.out.println("  " + getPrice("INFY"));            // live

        liveFeedUp = false;
        System.out.println("  " + getPrice("INFY"));            // falls back to cache

        cachedPrice = null;                                      // pretend cache was empty (cold start)
        System.out.println("  " + getPrice("INFY"));            // falls back to default

        System.out.println("\nB) Dashboard: critical data vs optional widget");
        String portfolio = loadPortfolioValue();                                     // if THIS fails, show an error
        List<String> recs = withFallback(FallbackDemo::loadRecommendations,
                List.of(), "recommendations");                                       // if THIS fails, hide the widget
        System.out.println("  " + portfolio);
        System.out.println("  Recommendations: " + (recs.isEmpty() ? "(section hidden)" : recs));

        System.out.println("\nRule: fallback must be SAFE. Never fall back to a fake balance or a guessed "
                + "payment result. Stale price: ok. Guessed balance: never.");
    }
}
