# Microservices Resilience - Simple Java Demos

## Plain Java (no dependencies, JDK 17+) - run with `java File.java`

| # | File | Topic | What you will SEE |
|---|---|---|---|
| 8 | `TimeoutDemo.java` | Timeouts | Without a timeout a cheap request waits ~4 s; with a 300 ms timeout ~0.6 s |
| 9 | `RetryBackoffDemo.java` | Retry + backoff + jitter | Growing waits, bounded attempts, no retry on permanent errors |
| 10 | `CircuitBreakerDemo.java` | Circuit breaker | CLOSED -> OPEN -> HALF_OPEN -> CLOSED, with rejected calls never touching the service |
| 11 | `BulkheadDemo.java` | Bulkhead | Shared pool: notification takes ~3 s; separate pools: ~50 ms. Plus a semaphore version |
| 12 | `RateLimiterDemo.java` | Token bucket | Burst of 5 allowed, rest rejected, then tokens drip back |
| 13 | `FallbackDemo.java` | Fallbacks / graceful degradation | Live -> cached -> default; optional widget hidden instead of failing the page |
| 14 | `IdempotencyDemo.java` | Idempotency keys | Naive service charges 3 times; keyed service charges once, even with 5 simultaneous retries |
| 15 | `HealthProbesDemo.java` | Liveness vs readiness | Simulated Kubernetes decisions: no traffic vs restart |

```
java TimeoutDemo.java
java RetryBackoffDemo.java
java CircuitBreakerDemo.java
java BulkheadDemo.java
java RateLimiterDemo.java
java FallbackDemo.java
java IdempotencyDemo.java
java HealthProbesDemo.java
```

## `spring_resilience/` - the library / Spring Boot versions

| File | Topic |
|---|---|
| `Resilience4jProgrammaticDemo.java` | #9 and #10 with Resilience4j used directly (run `main` from your IDE) |
| `ResilienceApplication.java` | `@Retry`, `@CircuitBreaker`, `@RateLimiter`, `@Bulkhead` + fallback; custom `HealthIndicator`; liveness/readiness switches |
| `application.yml` | Resilience4j settings and Actuator probe configuration |
| `k8s-probes.yaml` | How Kubernetes calls the liveness/readiness endpoints |

Run with `mvn spring-boot:run`, then follow the curl commands in the comment at the top of
`ResilienceApplication.java`.

NOTE: the `spring_resilience` folder has not been compiled or run by the author (the sandbox it was
written in cannot download Maven dependencies). If something does not compile, send the error and it
will be fixed.
