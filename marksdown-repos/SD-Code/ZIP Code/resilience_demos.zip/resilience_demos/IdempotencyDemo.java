import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 14. IDEMPOTENCY - doing the same request twice has the same effect as doing it once.
 *
 * The problem: you tap "Pay 500". The server charges you, but the response is lost
 * (network blip). Your app sees a timeout and RETRIES. Without protection you are charged twice.
 *
 * The fix: the client sends a unique Idempotency-Key with the request (one key per
 * payment attempt, reused on every retry). The server remembers: "I already processed
 * this key, here is the original result", and does NOT charge again.
 *
 * Run: java IdempotencyDemo.java
 */
public class IdempotencyDemo {

    record PaymentResult(String txnId, int amount) {
    }

    // ---------- Naive payment service ----------
    static class NaivePaymentService {
        final AtomicInteger balance = new AtomicInteger(1000);
        private final AtomicInteger txnCounter = new AtomicInteger();

        PaymentResult pay(int amount) {
            balance.addAndGet(-amount);                              // charged EVERY time it is called
            return new PaymentResult("TXN-" + txnCounter.incrementAndGet(), amount);
        }
    }

    // ---------- Idempotent payment service ----------
    static class IdempotentPaymentService {
        final AtomicInteger balance = new AtomicInteger(1000);
        private final AtomicInteger txnCounter = new AtomicInteger();

        private record Stored(int amount, PaymentResult result) {
        }

        private final Map<String, Stored> processed = new ConcurrentHashMap<>();  // key -> original result

        PaymentResult pay(String idempotencyKey, int amount) {
            // computeIfAbsent is atomic per key: even 5 simultaneous retries run the charge ONCE
            Stored stored = processed.computeIfAbsent(idempotencyKey, k -> {
                balance.addAndGet(-amount);
                return new Stored(amount, new PaymentResult("TXN-" + txnCounter.incrementAndGet(), amount));
            });
            if (stored.amount() != amount) {                         // same key, different request = client bug
                throw new IllegalStateException("Idempotency key reused with a different amount");
            }
            return stored.result();                                  // replay the ORIGINAL result
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("A) NAIVE service. Client times out and retries 2 times:");
        NaivePaymentService naive = new NaivePaymentService();
        for (int attempt = 1; attempt <= 3; attempt++) {
            PaymentResult r = naive.pay(500);
            System.out.println("  attempt " + attempt + " -> " + r.txnId() + ", balance now " + naive.balance);
        }
        System.out.println("  Customer wanted to pay 500 once, lost " + (1000 - naive.balance.get()) + ". BUG.\n");

        System.out.println("B) IDEMPOTENT service. Same key on every retry:");
        IdempotentPaymentService safe = new IdempotentPaymentService();
        for (int attempt = 1; attempt <= 3; attempt++) {
            PaymentResult r = safe.pay("order-123-attempt-1", 500);
            System.out.println("  attempt " + attempt + " -> " + r.txnId() + ", balance now " + safe.balance);
        }
        System.out.println("  Charged exactly once, same transaction id returned each time.\n");

        System.out.println("C) A genuinely NEW payment uses a NEW key:");
        PaymentResult second = safe.pay("order-456-attempt-1", 200);
        System.out.println("  -> " + second.txnId() + ", balance now " + safe.balance + "\n");

        System.out.println("D) Five threads send the same request at the SAME moment:");
        IdempotentPaymentService concurrent = new IdempotentPaymentService();
        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Thread t = new Thread(() -> concurrent.pay("order-789", 500));
            threads.add(t);
            t.start();
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("  balance now " + concurrent.balance + " (charged once, not five times)\n");

        System.out.println("E) Same key but a DIFFERENT amount is rejected (protects against client bugs):");
        try {
            safe.pay("order-123-attempt-1", 900);
        } catch (IllegalStateException e) {
            System.out.println("  rejected: " + e.getMessage());
        }

        System.out.println("\nReal systems store keys in a database/Redis with an expiry (e.g. 24h),"
                + " ideally in the same transaction as the charge.");
    }
}
