/**
 * 12. RATE LIMITING - TOKEN BUCKET
 *
 * Picture: a bucket that holds up to 5 tokens. Every request must take one token.
 * A tap drips 2 new tokens into the bucket every second (never above the capacity).
 *
 *  - Bucket full  -> a burst of up to 5 requests is allowed instantly.
 *  - Bucket empty -> further requests are rejected (HTTP 429 Too Many Requests).
 *  - Over time    -> the average rate cannot exceed 2 requests/second.
 *
 * Why: protect yourself from abusive clients and protect downstream services from overload.
 * Real systems keep one bucket per user/API key (and usually in Redis for several servers).
 *
 * Run: java RateLimiterDemo.java
 */
public class RateLimiterDemo {

    static class TokenBucket {
        private final double capacity;
        private final double refillPerSecond;
        private double tokens;
        private long lastRefillNanos;

        TokenBucket(double capacity, double refillPerSecond) {
            this.capacity = capacity;
            this.refillPerSecond = refillPerSecond;
            this.tokens = capacity;                       // starts full
            this.lastRefillNanos = System.nanoTime();
        }

        synchronized boolean tryAcquire() {
            refill();
            if (tokens >= 1) {
                tokens -= 1;
                return true;
            }
            return false;
        }

        synchronized double availableTokens() {
            refill();
            return tokens;
        }

        // Lazy refill: no background thread, just work out how much time has passed
        private void refill() {
            long now = System.nanoTime();
            double secondsPassed = (now - lastRefillNanos) / 1_000_000_000.0;
            tokens = Math.min(capacity, tokens + secondsPassed * refillPerSecond);
            lastRefillNanos = now;
        }
    }

    static void fire(TokenBucket bucket, int requests, String label) {
        System.out.println(label);
        for (int i = 1; i <= requests; i++) {
            boolean ok = bucket.tryAcquire();
            System.out.printf("  request %2d -> %s%n", i, ok ? "allowed" : "REJECTED (429 Too Many Requests)");
        }
        System.out.printf("  tokens left: %.2f%n%n", bucket.availableTokens());
    }

    public static void main(String[] args) throws Exception {
        TokenBucket bucket = new TokenBucket(5, 2);       // capacity 5, refill 2 tokens/second

        fire(bucket, 8, "1) A burst of 8 requests arrives at once (bucket holds 5):");

        System.out.println("   ...client waits 1 second (2 tokens drip in)...\n");
        Thread.sleep(1000);
        fire(bucket, 4, "2) 4 more requests after 1 second:");

        System.out.println("   ...client waits 3 seconds (bucket refills but never beyond capacity 5)...\n");
        Thread.sleep(3000);
        System.out.printf("3) Tokens now: %.2f (capped at 5, not 6)%n", bucket.availableTokens());
    }
}
