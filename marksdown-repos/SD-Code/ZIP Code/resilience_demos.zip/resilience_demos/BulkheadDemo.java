import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * 11. BULKHEAD - isolate resources so one slow dependency cannot sink everything.
 *
 * Picture: a ship is divided into watertight compartments. A hole floods one compartment,
 * not the whole ship.
 *
 * Part A (thread-pool bulkhead): payments are slow, notifications are fast.
 *   - One shared pool: slow payments hog every thread, notifications wait in line.
 *   - Separate pools: payments can only exhaust THEIR pool; notifications keep flowing.
 *
 * Part B (semaphore bulkhead): cap concurrent calls to a dependency and reject the
 *   overflow immediately instead of queueing forever.
 *
 * Run: java BulkheadDemo.java
 */
public class BulkheadDemo {

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    static String slowPayment() {
        sleep(1500);
        return "payment done";
    }

    static String fastNotification() {
        sleep(50);
        return "notification sent";
    }

    // ---------- Part A ----------
    static long timeNotification(ExecutorService paymentPool, ExecutorService notificationPool) throws Exception {
        for (int i = 0; i < 6; i++) {                  // flood of slow payment calls
            paymentPool.submit(BulkheadDemo::slowPayment);
        }
        long t0 = System.currentTimeMillis();
        notificationPool.submit(BulkheadDemo::fastNotification).get();
        return System.currentTimeMillis() - t0;
    }

    // ---------- Part B ----------
    static class SemaphoreBulkhead {
        private final Semaphore permits;

        SemaphoreBulkhead(int maxConcurrent) {
            this.permits = new Semaphore(maxConcurrent);
        }

        <T> T call(Callable<T> action) throws Exception {
            if (!permits.tryAcquire()) {               // do not wait, fail fast
                throw new RejectedExecutionException("bulkhead full");
            }
            try {
                return action.call();
            } finally {
                permits.release();
            }
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("A) Thread-pool bulkhead");

        ExecutorService shared = Executors.newFixedThreadPool(3);
        long slow = timeNotification(shared, shared);
        System.out.println("  ONE shared pool of 3 threads : notification took " + slow + " ms  <- stuck behind payments");
        shared.shutdownNow();

        ExecutorService paymentsOnly = Executors.newFixedThreadPool(3);
        ExecutorService notificationsOnly = Executors.newFixedThreadPool(2);
        long fast = timeNotification(paymentsOnly, notificationsOnly);
        System.out.println("  SEPARATE pools (3 + 2)       : notification took " + fast + " ms  <- unaffected");
        paymentsOnly.shutdownNow();
        notificationsOnly.shutdownNow();

        System.out.println("\nB) Semaphore bulkhead: at most 2 concurrent payment calls, extra calls rejected at once");
        SemaphoreBulkhead bulkhead = new SemaphoreBulkhead(2);
        ExecutorService callers = Executors.newFixedThreadPool(5);
        List<Future<String>> results = new ArrayList<>();
        for (int i = 1; i <= 5; i++) {
            final int id = i;
            results.add(callers.submit(() -> {
                try {
                    return "  caller " + id + ": " + bulkhead.call(BulkheadDemo::slowPayment);
                } catch (RejectedExecutionException e) {
                    return "  caller " + id + ": REJECTED (" + e.getMessage() + ")";
                }
            }));
            Thread.sleep(20);                          // callers arrive almost together
        }
        for (Future<String> f : results) {
            System.out.println(f.get());
        }
        callers.shutdownNow();

        System.out.println("\nLesson: give each dependency its own limited 'compartment'.");
    }
}
