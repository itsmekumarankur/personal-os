import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * 8. TIMEOUTS - why a call without a timeout can take your whole system down.
 *
 * Picture: a bank with 2 tellers (our server's worker threads). Each customer needs a
 * signature from a slow back office (the dependency, takes 2 seconds).
 *
 *  - No timeout: each teller stands waiting at the back office for 2s per customer.
 *    Everyone behind them in the queue waits too, even people who only need a quick
 *    balance check (the "health ping"). One slow dependency freezes the whole branch.
 *  - With timeout: a teller waits at most 300 ms, then tells the customer
 *    "try later" and serves the next person. The branch stays responsive.
 *
 * Run: java TimeoutDemo.java
 */
public class TimeoutDemo {

    static long start;

    static void log(String msg) {
        System.out.printf("  [%5d ms] %s%n", System.currentTimeMillis() - start, msg);
    }

    // The slow dependency (imagine a bank API that is having a bad day)
    static String slowDependency(int orderId) throws InterruptedException {
        Thread.sleep(2000);
        return "order-" + orderId + " confirmed";
    }

    static void scenario(String title, boolean useTimeout) throws Exception {
        System.out.println(title);
        start = System.currentTimeMillis();

        ExecutorService workers = Executors.newFixedThreadPool(2);   // our server's request threads
        ExecutorService outbound = Executors.newCachedThreadPool();  // used to make a call cancellable
        List<Future<?>> all = new ArrayList<>();

        for (int i = 1; i <= 4; i++) {
            final int id = i;
            all.add(workers.submit(() -> {
                try {
                    String result;
                    if (useTimeout) {
                        Future<String> call = outbound.submit(() -> slowDependency(id));
                        try {
                            result = call.get(300, TimeUnit.MILLISECONDS);   // <-- the timeout
                        } catch (TimeoutException e) {
                            call.cancel(true);                                // stop waiting, free the thread
                            result = "TIMED OUT after 300 ms -> fail fast";
                        }
                    } else {
                        result = slowDependency(id);                          // waits as long as it takes
                    }
                    log("request " + id + " done: " + result);
                } catch (Exception e) {
                    log("request " + id + " error: " + e);
                }
            }));
        }

        Thread.sleep(100);
        // A cheap request that does NOT even use the slow dependency
        all.add(workers.submit(() -> log("health ping answered (needs no dependency at all)")));

        for (Future<?> f : all) {
            f.get();
        }
        workers.shutdownNow();
        outbound.shutdownNow();
        System.out.println();
    }

    public static void main(String[] args) throws Exception {
        scenario("A) NO timeout: both workers get stuck, the cheap ping waits behind them", false);
        scenario("B) WITH 300 ms timeout: workers are released quickly, ping answered fast", true);
        System.out.println("Lesson: every remote call needs a timeout. Without it, the slowest "
                + "dependency decides how slow YOU are.");
    }
}
