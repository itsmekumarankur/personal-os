package com.example.resilience;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.core.IntervalFunction;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;

import java.time.Duration;
import java.util.function.Supplier;

/**
 * Resilience4j used directly (no Spring needed), the library version of the hand-written
 * RetryBackoffDemo and CircuitBreakerDemo.
 *
 * Run from your IDE (main method) after Maven has downloaded the dependencies.
 * Not executed in the sandbox this was written in.
 */
public class Resilience4jProgrammaticDemo {

    static int calls = 0;

    static String flakyService() {
        calls++;
        if (calls <= 2) {
            throw new IllegalStateException("503 (call #" + calls + ")");
        }
        return "SUCCESS on call #" + calls;
    }

    public static void main(String[] args) {

        // ---------------- RETRY with exponential backoff + jitter ----------------
        RetryConfig retryConfig = RetryConfig.custom()
                .maxAttempts(4)                                              // 1 call + 3 retries
                .intervalFunction(IntervalFunction.ofExponentialRandomBackoff(
                        Duration.ofMillis(200), 2.0, 0.5))                    // 200ms, 400ms, 800ms +/- 50%
                .retryExceptions(IllegalStateException.class)                // only retry these
                .build();
        Retry retry = Retry.of("flaky", retryConfig);
        retry.getEventPublisher().onRetry(e ->
                System.out.println("  retry #" + e.getNumberOfRetryAttempts()
                        + " after " + e.getWaitInterval().toMillis() + " ms because " + e.getLastThrowable().getMessage()));

        Supplier<String> retried = Retry.decorateSupplier(retry, Resilience4jProgrammaticDemo::flakyService);
        System.out.println("Retry demo: " + retried.get());

        // ---------------- CIRCUIT BREAKER ----------------
        CircuitBreakerConfig cbConfig = CircuitBreakerConfig.custom()
                .slidingWindowSize(4)                              // judge the last 4 calls
                .minimumNumberOfCalls(4)
                .failureRateThreshold(50)                          // 50% failures -> OPEN
                .waitDurationInOpenState(Duration.ofSeconds(2))    // cool-down
                .permittedNumberOfCallsInHalfOpenState(1)          // one trial call
                .build();
        CircuitBreaker breaker = CircuitBreaker.of("payments", cbConfig);
        breaker.getEventPublisher().onStateTransition(e ->
                System.out.println("  *** breaker: " + e.getStateTransition()));

        Supplier<String> alwaysFails = CircuitBreaker.decorateSupplier(breaker, () -> {
            throw new IllegalStateException("payment service down");
        });

        System.out.println("\nCircuit breaker demo:");
        for (int i = 1; i <= 6; i++) {
            try {
                alwaysFails.get();
            } catch (CallNotPermittedException e) {
                System.out.println("  call " + i + ": REJECTED instantly, state=" + breaker.getState());
            } catch (IllegalStateException e) {
                System.out.println("  call " + i + ": failed, state=" + breaker.getState());
            }
        }
    }
}
