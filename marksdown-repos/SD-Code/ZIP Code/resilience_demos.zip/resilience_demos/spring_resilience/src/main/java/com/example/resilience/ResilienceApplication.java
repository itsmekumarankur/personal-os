package com.example.resilience;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.availability.AvailabilityChangeEvent;
import org.springframework.boot.availability.LivenessState;
import org.springframework.boot.availability.ReadinessState;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Spring Boot version of the resilience ideas.
 * (Not run in the sandbox this was written in; see README. Start it with: mvn spring-boot:run)
 *
 * Try:
 *   curl localhost:8080/price/INFY                      -> works
 *   curl -X POST "localhost:8080/admin/price-feed?up=false"
 *   curl localhost:8080/price/INFY    (repeat 5-6 times) -> fallback answer, then the breaker opens
 *   curl localhost:8080/actuator/circuitbreakers         -> state of the breaker
 *   curl -X POST "localhost:8080/admin/gateway?up=false"
 *   curl localhost:8080/actuator/health/readiness        -> 503 OUT_OF_SERVICE (not ready)
 *   curl localhost:8080/actuator/health/liveness         -> still 200 UP (alive)
 *   curl -X POST localhost:8080/admin/break-liveness
 *   curl localhost:8080/actuator/health/liveness         -> 503 (Kubernetes would now restart the pod)
 */
@SpringBootApplication
public class ResilienceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResilienceApplication.class, args);
    }

    // =====================================================================================
    // Part 1: Retry + CircuitBreaker + Bulkhead + RateLimiter + fallback, all by annotation
    // =====================================================================================

    static final AtomicBoolean PRICE_FEED_UP = new AtomicBoolean(true);

    @Component
    static class PriceClient {
        private final AtomicInteger calls = new AtomicInteger();

        // Order of protection (outermost first): Retry -> CircuitBreaker -> RateLimiter -> Bulkhead -> method.
        // The fallback sits on the OUTERMOST annotation so it is used only after retries are exhausted,
        // or when the breaker is open / the limiter or bulkhead rejects the call.
        @Retry(name = "price", fallbackMethod = "priceFallback")
        @CircuitBreaker(name = "price")
        @RateLimiter(name = "price")
        @Bulkhead(name = "price")
        public String getPrice(String symbol) {
            int n = calls.incrementAndGet();
            if (!PRICE_FEED_UP.get()) {
                System.out.println("price feed call #" + n + " FAILED");
                throw new IllegalStateException("price feed unavailable");
            }
            System.out.println("price feed call #" + n + " ok");
            return symbol + " = 1523.40 (live)";
        }

        // Same parameters as the original method, plus the exception as the LAST parameter
        String priceFallback(String symbol, Throwable cause) {
            return symbol + " = 1520.00 (cached, stale) because: " + cause.getClass().getSimpleName();
        }
    }

    // =====================================================================================
    // Part 2: Health checks. Custom readiness dependency + endpoints to flip states for the demo
    // =====================================================================================

    static final AtomicBoolean PAYMENT_GATEWAY_UP = new AtomicBoolean(true);

    // Bean name becomes "paymentGateway" (class name minus "HealthIndicator"),
    // which is what the readiness group in application.yml refers to.
    @Component
    static class PaymentGatewayHealthIndicator implements HealthIndicator {
        @Override
        public Health health() {
            if (PAYMENT_GATEWAY_UP.get()) {
                return Health.up().withDetail("gateway", "reachable").build();
            }
            return Health.down().withDetail("gateway", "unreachable").build();
        }
    }

    @RestController
    static class DemoController {
        private final PriceClient priceClient;
        private final ApplicationEventPublisher events;

        DemoController(PriceClient priceClient, ApplicationEventPublisher events) {
            this.priceClient = priceClient;
            this.events = events;
        }

        @GetMapping("/price/{symbol}")
        String price(@PathVariable String symbol) {
            return priceClient.getPrice(symbol);
        }

        // ---- demo switches ----
        @PostMapping("/admin/price-feed")
        String priceFeed(@RequestParam boolean up) {
            PRICE_FEED_UP.set(up);
            return "price feed up = " + up;
        }

        @PostMapping("/admin/gateway")
        String gateway(@RequestParam boolean up) {
            PAYMENT_GATEWAY_UP.set(up);           // readiness goes DOWN, liveness unaffected
            return "payment gateway up = " + up;
        }

        @PostMapping("/admin/refuse-traffic")
        String refuseTraffic() {
            AvailabilityChangeEvent.publish(events, this, ReadinessState.REFUSING_TRAFFIC);
            return "readiness = REFUSING_TRAFFIC (e.g. drain before shutdown)";
        }

        @PostMapping("/admin/break-liveness")
        String breakLiveness() {
            AvailabilityChangeEvent.publish(events, this, LivenessState.BROKEN);
            return "liveness = BROKEN (Kubernetes would restart this pod)";
        }
    }
}
