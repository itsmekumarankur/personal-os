import java.util.concurrent.Callable;

/**
 * 10. CIRCUIT BREAKER - stop calling a service that is clearly broken.
 *
 * Picture: the fuse box at home. When something is faulty, the fuse trips so the whole
 * house does not burn down. After a while you try the switch again.
 *
 *   CLOSED     normal. Calls go through. Failures are counted.
 *      | too many failures in a row
 *      v
 *   OPEN       calls are rejected INSTANTLY (no waiting, the broken service gets breathing room)
 *      | after a cool-down period
 *      v
 *   HALF_OPEN  let ONE trial call through
 *      |-- trial succeeds -> CLOSED (back to normal)
 *      |-- trial fails    -> OPEN again (another cool-down)
 *
 * (Teaching version: it holds a lock during the call. Resilience4j is lock-free and
 * counts failure RATE over a sliding window. Concept is identical.)
 *
 * Run: java CircuitBreakerDemo.java
 */
public class CircuitBreakerDemo {

    enum State {CLOSED, OPEN, HALF_OPEN}

    static class CircuitOpenException extends RuntimeException {
        CircuitOpenException() {
            super("circuit is OPEN, call rejected without touching the service");
        }
    }

    static class CircuitBreaker {
        private final int failureThreshold;
        private final long openMillis;
        private State state = State.CLOSED;
        private int consecutiveFailures = 0;
        private long openedAt = 0;

        CircuitBreaker(int failureThreshold, long openMillis) {
            this.failureThreshold = failureThreshold;
            this.openMillis = openMillis;
        }

        synchronized State state() {
            return state;
        }

        synchronized <T> T call(Callable<T> action) throws Exception {
            if (state == State.OPEN) {
                if (System.currentTimeMillis() - openedAt >= openMillis) {
                    move(State.HALF_OPEN, "cool-down over, allowing one trial call");
                } else {
                    throw new CircuitOpenException();
                }
            }
            try {
                T result = action.call();
                consecutiveFailures = 0;
                if (state == State.HALF_OPEN) {
                    move(State.CLOSED, "trial call succeeded");
                }
                return result;
            } catch (Exception e) {
                consecutiveFailures++;
                if (state == State.HALF_OPEN) {
                    openedAt = System.currentTimeMillis();
                    move(State.OPEN, "trial call failed");
                } else if (consecutiveFailures >= failureThreshold) {
                    openedAt = System.currentTimeMillis();
                    move(State.OPEN, consecutiveFailures + " failures in a row");
                }
                throw e;
            }
        }

        private void move(State to, String why) {
            System.out.println("      *** state change: " + state + " -> " + to + "  (" + why + ")");
            state = to;
        }
    }

    // ---- the downstream service we protect ----
    static boolean serviceUp = true;
    static int realCallsMade = 0;

    static String paymentService() {
        realCallsMade++;
        if (!serviceUp) {
            throw new RuntimeException("service unavailable");
        }
        return "payment ok";
    }

    static void attempt(CircuitBreaker cb, int n) {
        int before = realCallsMade;
        String outcome;
        try {
            outcome = cb.call(CircuitBreakerDemo::paymentService);
        } catch (CircuitOpenException e) {
            outcome = "REJECTED instantly (" + e.getMessage() + ")";
        } catch (Exception e) {
            outcome = "FAILED (" + e.getMessage() + ")";
        }
        String touched = realCallsMade > before ? "service called" : "service NOT called";
        System.out.printf("  call %2d | state=%-9s | %-17s | %s%n", n, cb.state(), touched, outcome);
    }

    public static void main(String[] args) throws Exception {
        CircuitBreaker cb = new CircuitBreaker(3, 1000);  // trip after 3 failures, stay open 1 second
        int n = 0;

        System.out.println("Phase 1: service healthy");
        for (int i = 0; i < 2; i++) attempt(cb, ++n);

        System.out.println("\nPhase 2: service goes down, failures pile up and the breaker trips");
        serviceUp = false;
        for (int i = 0; i < 3; i++) attempt(cb, ++n);

        System.out.println("\nPhase 3: breaker is OPEN, callers fail fast, broken service is left alone");
        for (int i = 0; i < 3; i++) attempt(cb, ++n);

        System.out.println("\nPhase 4: after cool-down one trial call is allowed, service STILL down");
        Thread.sleep(1100);
        attempt(cb, ++n);
        attempt(cb, ++n);

        System.out.println("\nPhase 5: service recovers, next trial after cool-down closes the breaker");
        serviceUp = true;
        Thread.sleep(1100);
        attempt(cb, ++n);
        attempt(cb, ++n);

        System.out.println("\nTotal calls made: " + n + ", calls that actually hit the service: " + realCallsMade);
    }
}
