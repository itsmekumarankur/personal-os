/**
 * 15. HEALTH CHECKS - LIVENESS vs READINESS (simulation; the Spring Actuator version is in the spring folder)
 *
 * Two different questions an orchestrator (Kubernetes) keeps asking your service:
 *
 *   LIVENESS  : "Are you alive, or hopelessly stuck?"   -> if NO: RESTART the container.
 *   READINESS : "Can you serve traffic RIGHT NOW?"       -> if NO: stop sending requests, but do NOT restart.
 *
 * Picture: a shop. Readiness = the "OPEN / CLOSED" sign (closed while restocking, shop is fine).
 * Liveness = "is the shopkeeper conscious?" (if not, call an ambulance = restart).
 *
 * Common mistake: putting "database is down" into the LIVENESS check. Then Kubernetes restarts
 * every pod while the DB is down and makes the outage worse. DB down = not READY, still ALIVE.
 *
 * Run: java HealthProbesDemo.java
 */
public class HealthProbesDemo {

    static class App {
        boolean started = false;      // finished startup (caches warmed, etc.)
        boolean dbUp = true;
        boolean deadlocked = false;   // unrecoverable internal problem

        boolean liveness() {          // ONLY "is the process itself healthy?"
            return !deadlocked;
        }

        boolean readiness() {         // "can I do useful work now?" (includes dependencies)
            return started && dbUp && !deadlocked;
        }

        void restart() {
            started = false;
            deadlocked = false;
            dbUp = true;
        }
    }

    static void probe(int tick, String event, App app) {
        boolean alive = app.liveness();
        boolean ready = app.readiness();
        String action;
        if (!alive) {
            action = "RESTART the container";
        } else if (!ready) {
            action = "remove from load balancer (no traffic), do NOT restart";
        } else {
            action = "send traffic";
        }
        System.out.printf("  t=%d | %-38s | live=%-5s ready=%-5s -> %s%n", tick, event, alive, ready, action);
        if (!alive) {
            app.restart();
        }
    }

    public static void main(String[] args) {
        App app = new App();
        System.out.println("Kubernetes keeps probing the app and decides what to do:\n");

        probe(1, "app is still starting up", app);

        app.started = true;
        probe(2, "startup finished", app);

        app.dbUp = false;
        probe(3, "database goes down", app);

        app.dbUp = true;
        probe(4, "database recovers", app);

        app.deadlocked = true;
        probe(5, "threads deadlocked (cannot recover)", app);

        app.started = true;
        probe(6, "after restart, startup finished again", app);

        System.out.println("\nTakeaways:");
        System.out.println("  - t=1: not ready yet but alive. Killing a slow-starting app would loop forever.");
        System.out.println("  - t=3: dependency outage -> not ready, still alive. Restarting would not fix the DB.");
        System.out.println("  - t=5: only a truly stuck process is restarted.");
    }
}
