"""No API key or network needed: the model is a scripted fake and weather uses an injected fetcher."""
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import agent
from main import app
from tools import ToolError, calculator, get_weather


def text(t):
    return NS(stop_reason="end_turn", content=[NS(type="text", text=t)])


def use_tool(name, args, id="t1"):
    return NS(stop_reason="tool_use", content=[NS(type="tool_use", id=id, name=name, input=args)])


def script(monkeypatch, replies):
    seen = []
    it = iter(replies)

    def fake(messages):
        seen.append([dict(m) for m in messages])
        return next(it)

    monkeypatch.setattr(agent, "call_model", fake)
    return seen


# ---------- calculator ----------

@pytest.mark.parametrize("expr,out", [("2+3*4", "14"), ("(1200*1.18)/12", "118.0"), ("-5+2", "-3"),
                                      ("7//2", "3"), ("2**10", "1024"), ("10%3", "1")])
def test_calculator_ok(expr, out):
    assert calculator(expr) == out


@pytest.mark.parametrize("expr", ["__import__('os').system('id')", "open('x')", "a+1", "[1]", "2**99999",
                                  "1/0", "", "   ", "2+", "9" * 300, "(lambda: 1)()", "'a'*5"])
def test_calculator_rejects_unsafe_or_bad(expr):
    with pytest.raises(ToolError):
        calculator(expr)


# ---------- weather ----------

def fake_http(url, params):
    if "geocoding" in url:
        return {"results": [{"name": "Chennai", "country": "India", "latitude": 13.08, "longitude": 80.27}]}
    return {"current_weather": {"temperature": 31.2, "windspeed": 12.0, "weathercode": 2}}


def test_weather_ok():
    assert get_weather("Chennai", fake_http) == "Chennai, India: 31.2°C, partly cloudy, wind 12.0 km/h"


def test_weather_unknown_city():
    with pytest.raises(ToolError, match="not found"):
        get_weather("Nowhereville", lambda u, p: {"results": []})


def test_weather_service_down_is_a_clean_error():
    import httpx

    def boom(u, p):
        raise httpx.ConnectError("down")

    with pytest.raises(ToolError, match="unavailable"):
        get_weather("Chennai", boom)


def test_weather_rejects_empty_city():
    with pytest.raises(ToolError):
        get_weather("  ", fake_http)


# ---------- the loop ----------

def test_no_tool_needed(monkeypatch):
    script(monkeypatch, [text("Hello!")])
    r = agent.run_agent("hi")
    assert r == {"answer": "Hello!", "steps": [], "finished": True}


def test_tool_result_is_sent_back_to_the_model(monkeypatch):
    seen = script(monkeypatch, [use_tool("calculator", {"expression": "15/100*2400"}), text("It is 360.")])
    r = agent.run_agent("15% of 2400?")
    assert r["answer"] == "It is 360." and r["finished"]
    assert r["steps"] == [{"tool": "calculator", "input": {"expression": "15/100*2400"},
                           "output": "360.0", "is_error": False}]
    result_msg = seen[1][-1]["content"][0]
    assert result_msg["type"] == "tool_result" and result_msg["tool_use_id"] == "t1"
    assert result_msg["content"] == "360.0" and result_msg["is_error"] is False


def test_tool_error_goes_to_model_not_crash(monkeypatch):
    seen = script(monkeypatch, [use_tool("calculator", {"expression": "1/0"}), text("Cannot divide by zero.")])
    r = agent.run_agent("1/0")
    assert r["steps"][0]["is_error"] is True
    assert seen[1][-1]["content"][0]["is_error"] is True
    assert r["finished"]


def test_unknown_tool_and_bad_args(monkeypatch):
    script(monkeypatch, [use_tool("rm_rf", {}), use_tool("calculator", {"wrong": 1}), text("done")])
    r = agent.run_agent("x")
    assert [s["is_error"] for s in r["steps"]] == [True, True]
    assert r["steps"][0]["output"] == "unknown tool: rm_rf"


def test_turn_cap_stops_a_looping_model(monkeypatch):
    script(monkeypatch, [use_tool("calculator", {"expression": "1+1"}) for _ in range(agent.MAX_TURNS + 3)])
    r = agent.run_agent("loop")
    assert r["finished"] is False and len(r["steps"]) == agent.MAX_TURNS


def test_two_tools_in_one_reply(monkeypatch):
    both = NS(stop_reason="tool_use", content=[
        NS(type="tool_use", id="a", name="calculator", input={"expression": "1+1"}),
        NS(type="tool_use", id="b", name="calculator", input={"expression": "2+2"})])
    seen = script(monkeypatch, [both, text("2 and 4")])
    agent.run_agent("x")
    ids = [c["tool_use_id"] for c in seen[1][-1]["content"]]
    assert ids == ["a", "b"]


# ---------- HTTP ----------

def test_api(monkeypatch):
    c = TestClient(app)
    assert c.get("/health").json() == {"status": "ok"}
    script(monkeypatch, [text("hi")])
    assert c.post("/ask", json={"question": "hello"}).json()["answer"] == "hi"
    assert c.post("/ask", json={"question": ""}).status_code == 422


def test_model_error_is_502(monkeypatch):
    import anthropic
    import httpx

    def boom(messages):
        raise anthropic.APIConnectionError(request=httpx.Request("POST", "http://x"))

    monkeypatch.setattr(agent, "call_model", boom)
    assert TestClient(app).post("/ask", json={"question": "hi"}).status_code == 502
