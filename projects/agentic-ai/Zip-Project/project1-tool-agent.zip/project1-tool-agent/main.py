from anthropic import APIError
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from agent import run_agent

app = FastAPI(title="Agentic AI — Project 1: Tool-Using Agent")


class Ask(BaseModel):
    question: str = Field(min_length=1, max_length=2000)


class Step(BaseModel):
    tool: str
    input: dict
    output: str
    is_error: bool


class Answer(BaseModel):
    answer: str
    steps: list[Step]
    finished: bool


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/ask", response_model=Answer)
def ask(req: Ask):
    try:
        return run_agent(req.question)
    except APIError as e:
        raise HTTPException(status_code=502, detail=f"Model API error: {e}")
