# Project 1 — Tool-Using Agent

A small API where Claude can call two tools: a **calculator** and a **weather lookup**. This is the base pattern every later project builds on.

Grounded in Anthropic's tool-use loop: send the question and tool list, run any tool Claude asks for, send the result back, repeat until Claude answers.

## Read the code in this order
1. `tools.py` — the two tools and their JSON schemas. Note the calculator never uses `eval()`.
2. `agent.py` — the loop (`run_agent`), about 40 lines. This is the heart of the project.
3. `main.py` — `/health` and `/ask`.
4. `tests/test_agent.py` — 30 tests using a scripted fake model. No API key or network.

## Run the tests (no key needed)
    pip install -r requirements-dev.txt
    python -m pytest -q
    ruff check .

## Run it for real
    export ANTHROPIC_API_KEY=sk-ant-...
    python cli.py "What is 18% of 4500, and what is the weather in Chennai?"
    uvicorn main:app --port 8000
    curl -X POST localhost:8000/ask -H 'content-type: application/json' -d '{"question":"What is 15% of 2400?"}'

## What is protected
| Risk | Control |
|---|---|
| Model sends code as the "expression" | Parsed into a syntax tree; only numbers and `+ - * / // % **` allowed |
| `9**9**9` hangs the server | Exponent capped at 1000 |
| Model loops forever on tools | `MAX_TURNS = 6` |
| A tool fails | Returned to the model as `is_error`, request does not crash |
| Model asks for a tool that does not exist | Returned as an error result |
| Weather service down | Clean `ToolError`; API returns the model's explanation |
| Provider outage | HTTP 502 |
| Container compromise | Runs as non-root user |

## Deploy to AWS ECS (Terraform)
1. Create the secret holding **the plain API key string** (not JSON):

       aws secretsmanager create-secret --name agentic-tool-agent/anthropic-key \
         --secret-string "sk-ant-..." --region ap-south-1

   (The earlier Google Doc version stored JSON in the secret, which the task then received as the whole JSON text. This version uses a plain string so `ANTHROPIC_API_KEY` is exactly the key.)
2. Create the ECR repo, build and push:

       aws ecr create-repository --repository-name agentic-tool-agent --region ap-south-1
       aws ecr get-login-password --region ap-south-1 | docker login --username AWS --password-stdin <ACCOUNT>.dkr.ecr.ap-south-1.amazonaws.com
       docker build --platform linux/amd64 -t <ACCOUNT>.dkr.ecr.ap-south-1.amazonaws.com/agentic-tool-agent:latest .
       docker push <ACCOUNT>.dkr.ecr.ap-south-1.amazonaws.com/agentic-tool-agent:latest
3. `cd infra && terraform init && terraform apply`, then `curl <app_url>/health`.
4. Clean up: `terraform destroy` (the load balancer costs money while it exists).

## Honest limits
- Tests use a fake model; the live API, Docker and AWS steps were not run by me.
- No authentication on `/ask`: anyone with the URL spends your tokens. Project 10 adds auth, rate limits and budgets.
- Open-Meteo is a free public service with no SLA.
- Terraform was format- and parse-checked only.

## Exercises
1. Add a `convert_currency` tool with a fixed rate table. Write the test first.
2. Make `MAX_TURNS` an environment variable.
3. Return token usage in the response.
4. Break the calculator on purpose (allow `eval`) and watch which tests fail.
