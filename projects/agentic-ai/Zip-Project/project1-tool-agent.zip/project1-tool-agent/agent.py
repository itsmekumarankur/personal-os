"""The agent loop (Anthropic's tool-use pattern):

    send the question and the tool list to Claude
    while Claude asks for a tool:
        run it, send the result back
    return Claude's final text

Safety limits: a turn cap (so a confused model cannot loop forever), unknown
tools and tool errors are returned to the model as is_error results instead of
crashing the request.
"""
import os

from anthropic import Anthropic

from tools import TOOL_SCHEMAS, TOOLS, ToolError

MODEL = os.environ.get("MODEL", "claude-sonnet-4-5")
MAX_TURNS = 6
SYSTEM = ("You are a helpful assistant with a calculator and a weather tool. "
          "Use the calculator for every calculation. Use get_weather for weather questions. "
          "If a tool returns an error, tell the user plainly.")

_client = None


def _get_client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    return _client


def call_model(messages):
    return _get_client().messages.create(model=MODEL, max_tokens=1024, system=SYSTEM,
                                         tools=TOOL_SCHEMAS, messages=messages)


def run_tool(name: str, args: dict) -> tuple[str, bool]:
    """Returns (text, is_error). Never raises."""
    fn = TOOLS.get(name)
    if fn is None:
        return f"unknown tool: {name}", True
    try:
        return fn(**args), False
    except ToolError as e:
        return str(e), True
    except TypeError:
        return "bad tool arguments", True


def run_agent(question: str) -> dict:
    messages = [{"role": "user", "content": question}]
    steps = []
    for _ in range(MAX_TURNS):
        resp = call_model(messages)
        if resp.stop_reason != "tool_use":
            text = "".join(b.text for b in resp.content if b.type == "text")
            return {"answer": text, "steps": steps, "finished": True}
        messages.append({"role": "assistant", "content": resp.content})
        results = []
        for b in resp.content:
            if b.type == "tool_use":
                out, is_err = run_tool(b.name, b.input)
                steps.append({"tool": b.name, "input": b.input, "output": out, "is_error": is_err})
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": out, "is_error": is_err})
        messages.append({"role": "user", "content": results})
    return {"answer": "Stopped: too many tool calls without a final answer.", "steps": steps, "finished": False}
