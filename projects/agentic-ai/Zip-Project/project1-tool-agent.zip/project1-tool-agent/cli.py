"""Ask from the terminal.   python cli.py "What is 18% of 4500, and is it raining in Chennai?" """
import sys

from agent import run_agent

r = run_agent(" ".join(sys.argv[1:]) or "What is 15% of 2400?")
for s in r["steps"]:
    print(f"[tool] {s['tool']}({s['input']}) -> {s['output']}" + ("  (error)" if s["is_error"] else ""))
print("\n" + r["answer"])
