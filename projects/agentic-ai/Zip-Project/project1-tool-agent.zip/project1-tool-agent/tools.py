"""The two tools the agent can use, plus their JSON schemas.

calculator  evaluates arithmetic safely. It parses the expression into a syntax
            tree and only allows numbers and + - * / // % **. It never calls
            eval(), because the expression comes from a model.
get_weather looks up current weather from Open-Meteo (free, no API key).
"""
import ast
import operator

import httpx

_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
}
_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}
MAX_EXPR_LEN = 200
MAX_EXPONENT = 1000          # stops 9**9**9 style requests that would hang the server


class ToolError(Exception):
    """A problem the model should see and can recover from."""


def _eval(node):
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        left, right = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(right) > MAX_EXPONENT:
            raise ToolError("exponent too large")
        try:
            return _OPS[type(node.op)](left, right)
        except ZeroDivisionError:
            raise ToolError("division by zero")
        except OverflowError:
            raise ToolError("number too large")
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY:
        return _UNARY[type(node.op)](_eval(node.operand))
    raise ToolError("only numbers and + - * / // % ** are allowed")


def calculator(expression: str) -> str:
    if not isinstance(expression, str) or not expression.strip():
        raise ToolError("expression is required")
    if len(expression) > MAX_EXPR_LEN:
        raise ToolError("expression too long")
    try:
        tree = ast.parse(expression.strip(), mode="eval")
    except SyntaxError:
        raise ToolError("could not parse the expression")
    result = _eval(tree.body)
    if isinstance(result, float):
        result = round(result, 10)
    return str(result)


WEATHER_CODES = {0: "clear sky", 1: "mainly clear", 2: "partly cloudy", 3: "overcast", 45: "fog",
                 51: "light drizzle", 61: "light rain", 63: "rain", 65: "heavy rain",
                 80: "rain showers", 95: "thunderstorm"}


def get_weather(city: str, http_get=None) -> str:
    """http_get(url, params) -> dict. Injected in tests so no network is needed."""
    if not isinstance(city, str) or not city.strip() or len(city) > 80:
        raise ToolError("city is required (max 80 characters)")
    get = http_get or _http_get
    try:
        geo = get("https://geocoding-api.open-meteo.com/v1/search", {"name": city.strip(), "count": 1})
        places = geo.get("results") or []
        if not places:
            raise ToolError(f"city not found: {city}")
        p = places[0]
        w = get("https://api.open-meteo.com/v1/forecast",
                {"latitude": p["latitude"], "longitude": p["longitude"], "current_weather": "true"})
        cur = w["current_weather"]
    except ToolError:
        raise
    except (httpx.HTTPError, KeyError, ValueError):
        raise ToolError("weather service unavailable, try again later")
    sky = WEATHER_CODES.get(cur.get("weathercode"), "unknown conditions")
    return f"{p['name']}, {p.get('country', '')}: {cur['temperature']}°C, {sky}, wind {cur['windspeed']} km/h"


def _http_get(url, params):
    r = httpx.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json()


TOOL_SCHEMAS = [
    {"name": "calculator",
     "description": "Evaluate an arithmetic expression, e.g. '(1200 * 1.18) / 12'. Use it for any calculation instead of doing the math yourself.",
     "input_schema": {"type": "object",
                      "properties": {"expression": {"type": "string", "description": "Arithmetic using numbers and + - * / // % ** and parentheses"}},
                      "required": ["expression"]}},
    {"name": "get_weather",
     "description": "Get the current weather for a city.",
     "input_schema": {"type": "object",
                      "properties": {"city": {"type": "string", "description": "City name, e.g. 'Chennai'"}},
                      "required": ["city"]}},
]

TOOLS = {"calculator": calculator, "get_weather": get_weather}
