"""LC-01  Your first model call.  Run: python lc_01_hello_llm.py"""
from langchain_core.messages import SystemMessage, HumanMessage
from common import get_llm

llm = get_llm()

# 1) Simplest call: a plain string becomes ONE human message.
reply = llm.invoke("In one sentence, what is LangChain?")
print("type    :", type(reply).__name__)      # AIMessage - the model's answer is an object, not a string
print("text    :", reply.text)
print("tokens  :", reply.usage_metadata)      # input/output token counts

# 2) Real apps send a LIST of messages: system rules + user input.
messages = [
    SystemMessage("You are a pirate. Reply in one short sentence."),
    HumanMessage("Explain what an API is."),
]
print("\nwith system message:", llm.invoke(messages).text)
