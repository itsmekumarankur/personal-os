"""LG-03  Reducers: what happens when two nodes write the SAME key?  No LLM.  Run: python lg_03_reducers.py"""
import operator
from typing import Annotated, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages


# A) No reducer -> the last write simply OVERWRITES.
class Overwrite(TypedDict):
    log: list[str]

# B) With a reducer -> new values are COMBINED with old ones (operator.add on lists = append).
class Append(TypedDict):
    log: Annotated[list[str], operator.add]


def build(schema):
    b = StateGraph(schema)
    b.add_node("a", lambda s: {"log": ["step A ran"]})
    b.add_node("b", lambda s: {"log": ["step B ran"]})
    b.add_edge(START, "a"); b.add_edge("a", "b"); b.add_edge("b", END)
    return b.compile()


print("without reducer:", build(Overwrite).invoke({"log": []}))
print("with reducer   :", build(Append).invoke({"log": []}))

# C) add_messages is the built-in reducer for chat history: appends, and merges by message id.
from langchain_core.messages import HumanMessage, AIMessage
merged = add_messages([HumanMessage("hi", id="1")], [AIMessage("hello", id="2")])
print("\nadd_messages ->", [(m.type, m.content) for m in merged])
