"""LC-15  A real agent (create_agent) that queries a SQLite database + remembers the chat.  Run: python lc_15_agent_sqlite.py"""
import sqlite3
from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from common import get_llm, ensure_demo_db

DB = ensure_demo_db()          # creates shop.db: products(id,name,price,stock), orders(id,product_id,qty,city)


@tool
def describe_database() -> str:
    """List all tables and their columns. Call this first to learn the schema."""
    con = sqlite3.connect(DB)
    out = []
    for (name,) in con.execute("SELECT name FROM sqlite_master WHERE type='table'"):
        cols = [r[1] for r in con.execute(f"PRAGMA table_info({name})")]
        out.append(f"{name}({', '.join(cols)})")
    return "\n".join(out)


@tool
def run_sql(query: str) -> str:
    """Run a READ-ONLY SQL SELECT query on the shop database and return the rows."""
    if not query.strip().lower().startswith("select"):
        return "Error: only SELECT queries are allowed."
    con = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)   # read-only connection = second safety lock
    try:
        return str(con.execute(query).fetchall())
    except Exception as e:
        return f"SQL error: {e}"                              # the model reads this and self-corrects


agent = create_agent(
    get_llm(),
    tools=[describe_database, run_sql],
    system_prompt="You answer questions about the shop database. Check the schema first, then query. Be concise.",
    checkpointer=InMemorySaver(),          # gives the agent memory across calls with the same thread_id
)

cfg = {"configurable": {"thread_id": "demo"}}
for question in ["Which products are out of stock?", "And what is the total quantity ordered from Chennai?"]:
    print("\n" + "=" * 70 + f"\nYOU: {question}")
    for step in agent.stream({"messages": [("user", question)]}, cfg, stream_mode="values"):
        step["messages"][-1].pretty_print()      # watch: AI asks tool -> tool result -> AI answer
