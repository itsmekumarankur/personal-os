"""LC-08  The TRUTH about memory: the model has none. You resend the history.  Run: python lc_08_memory_manual.py"""
from langchain_core.messages import SystemMessage, HumanMessage
from common import get_llm

llm = get_llm()

print("=== WITHOUT memory: each call is a fresh universe ===")
llm.invoke("My name is Ankur.")
print("AI:", llm.invoke("What is my name?").text)

print("\n=== WITH memory: we keep a list and resend it every time ===")
history = [SystemMessage("You are a concise assistant.")]

for user_text in ["My name is Ankur and I live in Chennai.", "What is my name and where do I live?"]:
    history.append(HumanMessage(user_text))
    ai = llm.invoke(history)          # the WHOLE list goes to the model
    history.append(ai)                # remember the answer too
    print(f"You: {user_text}\nAI : {ai.text}\n[messages sent this turn: {len(history) - 1}]\n")
