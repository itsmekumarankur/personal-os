"""EV-05  Evaluate the RETRIEVER on its own: Hit@k, Recall@k, Precision@k, MRR.  No LLM.  Run: python ev_05_retrieval_metrics.py"""
from eval_data import GOLDEN, CORPUS, retrieve

# Add questions phrased with different words than the documents (where keyword search struggles)
EXTRA = [
    {"id": "x1", "question": "How many vacation days do I get?",   "relevant_docs": ["d1"]},     # 'vacation' vs 'leave'
    {"id": "x2", "question": "Is remote working allowed?",          "relevant_docs": ["d2"]},     # 'remote working' vs 'work from home'
]
K = 3

def rank_of_first_relevant(retrieved, relevant):
    for i, d in enumerate(retrieved, start=1):
        if d in relevant:
            return i
    return None

hit1 = hitk = rr_sum = recall_sum = prec_sum = 0
items = GOLDEN + EXTRA
print(f"{'id':3} {'retrieved top-3':22} {'relevant':8} first-rank")
for item in items:
    got = retrieve(item["question"], K)
    rel = set(item["relevant_docs"])
    r = rank_of_first_relevant(got, rel)
    hit1 += (r == 1); hitk += (r is not None)
    rr_sum += (1 / r) if r else 0
    found = len(rel & set(got))
    recall_sum += found / len(rel)
    prec_sum += found / K
    print(f"{item['id']:3} {str(got):22} {str(sorted(rel)):8} {r}")

n = len(items)
print(f"\nHit@1       = {hit1 / n:.2f}   (was the right doc ranked first?)")
print(f"Hit@{K}       = {hitk / n:.2f}   (was the right doc anywhere in the top {K}?)")
print(f"Recall@{K}    = {recall_sum / n:.2f}   (fraction of relevant docs found)")
print(f"Precision@{K} = {prec_sum / n:.2f}   (fraction of retrieved docs that were relevant)")
print(f"MRR         = {rr_sum / n:.2f}   (mean of 1/rank: rewards ranking the right doc higher)")

print("""
How to read this:
  * Evaluate retrieval SEPARATELY from generation. If the right chunk never reaches the model, no prompt can fix it.
  * x1 and x2 are paraphrases. Keyword matching cannot connect 'vacation' to 'leave' or 'remote working' to
    'work from home', so x1 ranks the right doc low and x2 misses it entirely. Embeddings (LC-14) or hybrid
    search fix exactly this. Re-run after swapping in the vector retriever and compare MRR.
  * Precision@3 is naturally low here (only 1 relevant doc per question out of 3 slots). Watch the trend, not the absolute.""")
